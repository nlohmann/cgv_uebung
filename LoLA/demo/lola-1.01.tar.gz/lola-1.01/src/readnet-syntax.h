/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton interface for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     key_safe = 258,
     key_next = 259,
     key_analyse = 260,
     key_place = 261,
     key_marking = 262,
     key_transition = 263,
     key_consume = 264,
     key_produce = 265,
     comma = 266,
     colon = 267,
     semicolon = 268,
     ident = 269,
     number = 270,
     eqqual = 271,
     tand = 272,
     tor = 273,
     exists = 274,
     forall = 275,
     globally = 276,
     future = 277,
     until = 278,
     tnot = 279,
     tgeq = 280,
     tgt = 281,
     tleq = 282,
     tlt = 283,
     tneq = 284,
     key_formula = 285,
     lpar = 286,
     rpar = 287,
     key_state = 288,
     key_path = 289,
     key_generator = 290,
     key_record = 291,
     key_end = 292,
     key_sort = 293,
     key_function = 294,
     key_do = 295,
     key_array = 296,
     key_enumerate = 297,
     key_constant = 298,
     key_boolean = 299,
     key_of = 300,
     key_begin = 301,
     key_while = 302,
     key_if = 303,
     key_then = 304,
     key_else = 305,
     key_switch = 306,
     key_case = 307,
     key_repeat = 308,
     key_for = 309,
     key_to = 310,
     key_all = 311,
     key_exit = 312,
     key_return = 313,
     key_true = 314,
     key_false = 315,
     key_mod = 316,
     key_var = 317,
     key_guard = 318,
     tiff = 319,
     timplies = 320,
     lbrack = 321,
     rbrack = 322,
     dot = 323,
     pplus = 324,
     mminus = 325,
     times = 326,
     divide = 327,
     slash = 328,
     key_exists = 329,
     key_strong = 330,
     key_weak = 331,
     key_fair = 332
   };
#endif
/* Tokens.  */
#define key_safe 258
#define key_next 259
#define key_analyse 260
#define key_place 261
#define key_marking 262
#define key_transition 263
#define key_consume 264
#define key_produce 265
#define comma 266
#define colon 267
#define semicolon 268
#define ident 269
#define number 270
#define eqqual 271
#define tand 272
#define tor 273
#define exists 274
#define forall 275
#define globally 276
#define future 277
#define until 278
#define tnot 279
#define tgeq 280
#define tgt 281
#define tleq 282
#define tlt 283
#define tneq 284
#define key_formula 285
#define lpar 286
#define rpar 287
#define key_state 288
#define key_path 289
#define key_generator 290
#define key_record 291
#define key_end 292
#define key_sort 293
#define key_function 294
#define key_do 295
#define key_array 296
#define key_enumerate 297
#define key_constant 298
#define key_boolean 299
#define key_of 300
#define key_begin 301
#define key_while 302
#define key_if 303
#define key_then 304
#define key_else 305
#define key_switch 306
#define key_case 307
#define key_repeat 308
#define key_for 309
#define key_to 310
#define key_all 311
#define key_exit 312
#define key_return 313
#define key_true 314
#define key_false 315
#define key_mod 316
#define key_var 317
#define key_guard 318
#define tiff 319
#define timplies 320
#define lbrack 321
#define rbrack 322
#define dot 323
#define pplus 324
#define mminus 325
#define times 326
#define divide 327
#define slash 328
#define key_exists 329
#define key_strong 330
#define key_weak 331
#define key_fair 332




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 49 "readnet-syntax.yy"
{
	char * str;
	int value;
	UType * t;
	URcList * rcl;
	UEnList * el;
	ULVal * lval;
	int * exl;
	UStatement * stm;
	case_list * cl;
	UFunction * fu;
	UExpression * ex;
	arc_list * al;
	formula * form;
	IdList * idl;
	UTermList * tlist;
	Place * pl;
	Transition * tr;
	fmode * fm;
	TrSymbol * ts;
	VaSymbol * varsy;
}
/* Line 1489 of yacc.c.  */
#line 226 "readnet-syntax.h"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE yylval;

