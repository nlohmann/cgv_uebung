/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     key_safe = 258,
     key_next = 259,
     key_analyse = 260,
     key_place = 261,
     key_marking = 262,
     key_transition = 263,
     key_consume = 264,
     key_produce = 265,
     comma = 266,
     colon = 267,
     semicolon = 268,
     ident = 269,
     number = 270,
     eqqual = 271,
     tand = 272,
     tor = 273,
     exists = 274,
     forall = 275,
     globally = 276,
     future = 277,
     until = 278,
     tnot = 279,
     tgeq = 280,
     tgt = 281,
     tleq = 282,
     tlt = 283,
     tneq = 284,
     key_formula = 285,
     lpar = 286,
     rpar = 287,
     key_state = 288,
     key_path = 289,
     key_generator = 290,
     key_record = 291,
     key_end = 292,
     key_sort = 293,
     key_function = 294,
     key_do = 295,
     key_array = 296,
     key_enumerate = 297,
     key_constant = 298,
     key_boolean = 299,
     key_of = 300,
     key_begin = 301,
     key_while = 302,
     key_if = 303,
     key_then = 304,
     key_else = 305,
     key_switch = 306,
     key_case = 307,
     key_repeat = 308,
     key_for = 309,
     key_to = 310,
     key_all = 311,
     key_exit = 312,
     key_return = 313,
     key_true = 314,
     key_false = 315,
     key_mod = 316,
     key_var = 317,
     key_guard = 318,
     tiff = 319,
     timplies = 320,
     lbrack = 321,
     rbrack = 322,
     dot = 323,
     pplus = 324,
     mminus = 325,
     times = 326,
     divide = 327,
     slash = 328,
     key_exists = 329,
     key_strong = 330,
     key_weak = 331,
     key_fair = 332
   };
#endif
/* Tokens.  */
#define key_safe 258
#define key_next 259
#define key_analyse 260
#define key_place 261
#define key_marking 262
#define key_transition 263
#define key_consume 264
#define key_produce 265
#define comma 266
#define colon 267
#define semicolon 268
#define ident 269
#define number 270
#define eqqual 271
#define tand 272
#define tor 273
#define exists 274
#define forall 275
#define globally 276
#define future 277
#define until 278
#define tnot 279
#define tgeq 280
#define tgt 281
#define tleq 282
#define tlt 283
#define tneq 284
#define key_formula 285
#define lpar 286
#define rpar 287
#define key_state 288
#define key_path 289
#define key_generator 290
#define key_record 291
#define key_end 292
#define key_sort 293
#define key_function 294
#define key_do 295
#define key_array 296
#define key_enumerate 297
#define key_constant 298
#define key_boolean 299
#define key_of 300
#define key_begin 301
#define key_while 302
#define key_if 303
#define key_then 304
#define key_else 305
#define key_switch 306
#define key_case 307
#define key_repeat 308
#define key_for 309
#define key_to 310
#define key_all 311
#define key_exit 312
#define key_return 313
#define key_true 314
#define key_false 315
#define key_mod 316
#define key_var 317
#define key_guard 318
#define tiff 319
#define timplies 320
#define lbrack 321
#define rbrack 322
#define dot 323
#define pplus 324
#define mminus 325
#define times 326
#define divide 327
#define slash 328
#define key_exists 329
#define key_strong 330
#define key_weak 331
#define key_fair 332




/* Copy the first part of user declarations.  */
#line 1 "readnet-syntax.yy"

#include"dimensions.H"
#include"net.H"
#include"graph.H"
#include"symboltab.H"
#include"formula.H"
#include"unfold.H"
#include<stdio.h>
#include<limits.h>

extern UBooType * TheBooType;
extern UNumType * TheNumType;

#define YYDEBUG 1
void yyerror(char *);

class arc_list
{
 public:
	PlSymbol * place;
	UTermList * mt;
	unsigned int nu;
    arc_list    * next;
};   

class case_list
{
	public:
	UStatement * stm;
	UExpression * exp;
	case_list * next;
};

/* list of places and multiplicities to become arcs */

int CurrentCapacity;
UFunction * CurrentFunction;
Place *P;
Transition *T;
Symbol * S;
PlSymbol * PS;
TrSymbol * TS;
SymbolTab * GlobalTable;
SymbolTab * LocalTable;
UVar * V;
VaSymbol * VS;


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 1
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 49 "readnet-syntax.yy"
{
	char * str;
	int value;
	UType * t;
	URcList * rcl;
	UEnList * el;
	ULVal * lval;
	int * exl;
	UStatement * stm;
	case_list * cl;
	UFunction * fu;
	UExpression * ex;
	arc_list * al;
	formula * form;
	IdList * idl;
	UTermList * tlist;
	Place * pl;
	Transition * tr;
	fmode * fm;
	TrSymbol * ts;
	VaSymbol * varsy;
}
/* Line 187 of yacc.c.  */
#line 321 "readnet-syntax.cc"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */
#line 149 "readnet-syntax.yy"

extern YYSTYPE yylval;
//// LINE COMMENTED BY NIELS //// #include"lex.yy.c"
//// 3 LINES ADDED BY NIELS
extern int yylex();
extern FILE *yyin;
extern int yylineno;
 

/* Line 216 of yacc.c.  */
#line 342 "readnet-syntax.cc"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   441

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  78
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  83
/* YYNRULES -- Number of rules.  */
#define YYNRULES  202
/* YYNRULES -- Number of states.  */
#define YYNSTATES  416

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   332

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     6,    11,    17,    23,    29,    31,    33,
      38,    41,    45,    51,    53,    57,    58,    61,    64,    65,
      69,    71,    74,    79,    81,    83,    87,    92,    98,   102,
     104,   107,   109,   111,   114,   119,   123,   124,   127,   128,
     131,   136,   138,   142,   149,   150,   152,   156,   160,   164,
     166,   170,   172,   174,   176,   178,   180,   182,   184,   186,
     188,   194,   200,   210,   217,   223,   231,   234,   236,   241,
     248,   249,   252,   257,   261,   263,   268,   272,   276,   280,
     282,   286,   290,   292,   295,   297,   301,   305,   309,   313,
     317,   321,   323,   327,   331,   333,   337,   341,   345,   347,
     350,   352,   354,   358,   363,   367,   369,   371,   373,   375,
     377,   382,   383,   385,   389,   393,   395,   399,   401,   405,
     409,   413,   414,   423,   426,   431,   432,   435,   439,   443,
     445,   447,   451,   453,   455,   456,   458,   462,   466,   470,
     472,   476,   478,   482,   484,   489,   490,   492,   496,   498,
     501,   512,   514,   518,   522,   524,   526,   527,   530,   531,
     533,   537,   541,   545,   547,   551,   555,   559,   563,   567,
     571,   575,   579,   583,   586,   590,   595,   600,   604,   612,
     620,   625,   630,   635,   640,   645,   650,   652,   658,   662,
     663,   665,   670,   675,   679,   683,   686,   690,   692,   698,
     700,   702,   706
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      79,     0,    -1,    85,   132,    -1,    85,   132,    80,   153,
      -1,    85,   132,     5,     6,    84,    -1,    85,   132,     5,
       8,    81,    -1,    85,   132,     5,     7,   130,    -1,    30,
      -1,   138,    -1,    82,    66,    83,    67,    -1,   138,    68,
      -1,   138,    16,   118,    -1,    83,    73,   138,    16,   118,
      -1,   138,    -1,   138,    68,   118,    -1,    -1,    85,    86,
      -1,    38,    88,    -1,    -1,    39,    87,    95,    -1,    89,
      -1,    88,    89,    -1,    14,    16,    90,    13,    -1,    44,
      -1,    14,    -1,    36,    93,    37,    -1,    41,    90,    45,
      90,    -1,    66,    15,    11,    15,    67,    -1,    42,    91,
      37,    -1,    92,    -1,    92,    91,    -1,    14,    -1,    94,
      -1,    93,    94,    -1,    14,    12,    90,    13,    -1,   100,
      96,   103,    -1,    -1,    62,    97,    -1,    -1,    97,    98,
      -1,    99,    12,    90,    13,    -1,    14,    -1,    14,    11,
      99,    -1,    14,    31,   101,    32,    12,    90,    -1,    -1,
     102,    -1,   101,    13,   102,    -1,    99,    12,    90,    -1,
      46,   104,    37,    -1,   105,    -1,   104,    13,   105,    -1,
     106,    -1,   107,    -1,   108,    -1,   109,    -1,   110,    -1,
     113,    -1,   116,    -1,   111,    -1,   112,    -1,    47,   118,
      40,   104,    37,    -1,    53,   104,    23,   118,    37,    -1,
      54,    14,    16,   118,    55,   118,    40,   104,    37,    -1,
      54,    56,    14,    40,   104,    37,    -1,    48,   118,    49,
     104,    37,    -1,    48,   118,    49,   104,    50,   104,    37,
      -1,    58,   118,    -1,    57,    -1,    51,   118,   114,    37,
      -1,    51,   118,   114,    50,   104,    37,    -1,    -1,   115,
     114,    -1,    52,   118,    12,   104,    -1,   117,    16,   118,
      -1,    14,    -1,   117,    66,   118,    67,    -1,   117,    68,
      14,    -1,   118,    64,   119,    -1,   118,    65,   119,    -1,
     119,    -1,   119,    17,   120,    -1,   119,    18,   120,    -1,
     120,    -1,    24,   120,    -1,   121,    -1,   121,    16,   122,
      -1,   121,    26,   122,    -1,   121,    28,   122,    -1,   121,
      25,   122,    -1,   121,    27,   122,    -1,   121,    29,   122,
      -1,   122,    -1,   122,    69,   123,    -1,   122,    70,   123,
      -1,   123,    -1,   123,    71,   124,    -1,   123,    72,   124,
      -1,   123,    61,   124,    -1,   124,    -1,    70,   125,    -1,
     125,    -1,    14,    -1,   117,    68,    14,    -1,   117,    66,
     118,    67,    -1,    31,   118,    32,    -1,    59,    -1,    60,
      -1,   126,    -1,   128,    -1,    15,    -1,    14,    31,   127,
      32,    -1,    -1,   118,    -1,   118,    11,   127,    -1,    66,
     129,    67,    -1,   118,    -1,   118,    73,   129,    -1,   131,
      -1,   130,    11,   131,    -1,   138,    12,    15,    -1,   138,
      12,   141,    -1,    -1,     6,   134,    13,     7,   133,   139,
      13,   145,    -1,   135,   136,    -1,   134,    13,   135,   136,
      -1,    -1,     3,    12,    -1,     3,    15,    12,    -1,   136,
      11,   137,    -1,   137,    -1,   138,    -1,   138,    12,    90,
      -1,    14,    -1,    15,    -1,    -1,   140,    -1,   139,    11,
     140,    -1,   138,    12,    15,    -1,   138,    12,   141,    -1,
     142,    -1,   141,    69,   142,    -1,   143,    -1,   143,    12,
      15,    -1,    14,    -1,    14,    31,   144,    32,    -1,    -1,
     143,    -1,   143,    11,   144,    -1,   146,    -1,   145,   146,
      -1,     8,   148,   147,   149,     9,   150,    13,    10,   150,
      13,    -1,    96,    -1,    76,    77,    96,    -1,    75,    77,
      96,    -1,    14,    -1,    15,    -1,    -1,    63,   118,    -1,
      -1,   151,    -1,   151,    11,   150,    -1,   138,    12,    15,
      -1,   138,    12,   141,    -1,    15,    -1,    31,   118,    32,
      -1,   154,    16,   152,    -1,   154,    29,   152,    -1,   154,
      27,   152,    -1,   154,    25,   152,    -1,   154,    28,   152,
      -1,   154,    26,   152,    -1,   153,    17,   153,    -1,   153,
      18,   153,    -1,    24,   153,    -1,    66,   118,    67,    -1,
      74,   155,    12,   153,    -1,    56,   155,    12,   153,    -1,
      31,   153,    32,    -1,    19,   156,    66,   153,    23,   153,
      67,    -1,    20,   156,    66,   153,    23,   153,    67,    -1,
      19,   156,    21,   153,    -1,    20,   156,    21,   153,    -1,
      19,   156,     4,   153,    -1,    20,   156,     4,   153,    -1,
      19,   156,    22,   153,    -1,    20,   156,    22,   153,    -1,
     138,    -1,   138,    68,    31,   118,    32,    -1,   138,    12,
      90,    -1,    -1,   157,    -1,    74,   155,    12,   157,    -1,
      56,   155,    12,   157,    -1,   157,    17,   157,    -1,   157,
      18,   157,    -1,    24,   157,    -1,    31,   157,    32,    -1,
     158,    -1,   158,    68,    66,   159,    67,    -1,   138,    -1,
     160,    -1,   159,    73,   160,    -1,   138,    16,   118,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   159,   159,   164,   169,   183,   191,   193,   195,   205,
     263,   274,   286,   308,   314,   339,   340,   342,   343,   343,
     345,   346,   348,   360,   361,   369,   373,   381,   391,   395,
     396,   401,   413,   414,   420,   434,   440,   440,   441,   441,
     442,   457,   462,   469,   499,   499,   499,   500,   516,   518,
     519,   527,   528,   529,   530,   531,   532,   533,   534,   535,
     537,   547,   557,   576,   585,   595,   606,   616,   621,   643,
     666,   667,   669,   675,   685,   693,   708,   729,   741,   753,
     755,   767,   779,   781,   792,   794,   802,   810,   818,   826,
     834,   842,   844,   856,   868,   870,   882,   894,   906,   908,
     919,   921,   959,   985,  1006,  1007,  1011,  1015,  1016,  1017,
    1021,  1046,  1047,  1052,  1058,  1087,  1092,  1098,  1099,  1101,
    1120,  1162,  1162,  1291,  1292,  1294,  1295,  1296,  1298,  1299,
    1301,  1312,  1347,  1348,  1350,  1351,  1352,  1354,  1373,  1415,
    1416,  1418,  1419,  1422,  1443,  1474,  1475,  1476,  1482,  1483,
    1485,  1719,  1720,  1721,  1723,  1724,  1726,  1727,  1729,  1730,
    1731,  1736,  1754,  1779,  1784,  1792,  1799,  1806,  1813,  1820,
    1827,  1834,  1839,  1844,  1849,  1858,  1864,  1870,  1875,  1880,
    1885,  1890,  1895,  1900,  1905,  1910,  1916,  1924,  1937,  1945,
    1946,  1948,  1954,  1960,  1965,  1970,  1975,  1976,  1985,  1995,
    2001,  2002,  2007
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "key_safe", "key_next", "key_analyse",
  "key_place", "key_marking", "key_transition", "key_consume",
  "key_produce", "comma", "colon", "semicolon", "ident", "number",
  "eqqual", "tand", "tor", "exists", "forall", "globally", "future",
  "until", "tnot", "tgeq", "tgt", "tleq", "tlt", "tneq", "key_formula",
  "lpar", "rpar", "key_state", "key_path", "key_generator", "key_record",
  "key_end", "key_sort", "key_function", "key_do", "key_array",
  "key_enumerate", "key_constant", "key_boolean", "key_of", "key_begin",
  "key_while", "key_if", "key_then", "key_else", "key_switch", "key_case",
  "key_repeat", "key_for", "key_to", "key_all", "key_exit", "key_return",
  "key_true", "key_false", "key_mod", "key_var", "key_guard", "tiff",
  "timplies", "lbrack", "rbrack", "dot", "pplus", "mminus", "times",
  "divide", "slash", "key_exists", "key_strong", "key_weak", "key_fair",
  "$accept", "input", "formulaheader", "atransition", "hlprefix",
  "firingmode", "aplace", "declarations", "declaration", "@1",
  "sortdeclarations", "sortdeclaration", "sortdescription", "enums", "enu",
  "recordcomponents", "recordcomponent", "functiondeclaration",
  "vardeclarations", "vdeclarations", "vdeclaration", "identlist", "head",
  "fparlists", "fparlist", "body", "statement_seq", "statement",
  "while_statement", "repeat_statement", "for_statement",
  "forall_statement", "if_statement", "return_statement", "exit_statement",
  "case_statement", "caselist", "case", "assignment", "lvalue",
  "expression", "express", "expre", "expr", "exp", "term", "factor", "fac",
  "functioncall", "expressionlist", "arrayvalue", "valuelist",
  "amarkinglist", "amarking", "net", "@2", "placelists", "capacity",
  "placelist", "place", "nodeident", "markinglist", "marking", "multiterm",
  "mtcomponent", "hlterm", "termlist", "transitionlist", "transition",
  "transitionvariables", "tname", "guard", "arclist", "arc", "numex",
  "ctlformula", "cplace", "quantification", "transformula",
  "transitionformula", "formulatransition", "parfiringmode", "fmodeblock", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    78,    79,    79,    79,    79,    79,    80,    81,    81,
      82,    83,    83,    84,    84,    85,    85,    86,    87,    86,
      88,    88,    89,    90,    90,    90,    90,    90,    90,    91,
      91,    92,    93,    93,    94,    95,    96,    96,    97,    97,
      98,    99,    99,   100,   101,   101,   101,   102,   103,   104,
     104,   105,   105,   105,   105,   105,   105,   105,   105,   105,
     106,   107,   108,   109,   110,   110,   111,   112,   113,   113,
     114,   114,   115,   116,   117,   117,   117,   118,   118,   118,
     119,   119,   119,   120,   120,   121,   121,   121,   121,   121,
     121,   121,   122,   122,   122,   123,   123,   123,   123,   124,
     124,   125,   125,   125,   125,   125,   125,   125,   125,   125,
     126,   127,   127,   127,   128,   129,   129,   130,   130,   131,
     131,   133,   132,   134,   134,   135,   135,   135,   136,   136,
     137,   137,   138,   138,   139,   139,   139,   140,   140,   141,
     141,   142,   142,   143,   143,   144,   144,   144,   145,   145,
     146,   147,   147,   147,   148,   148,   149,   149,   150,   150,
     150,   151,   151,   152,   152,   153,   153,   153,   153,   153,
     153,   153,   153,   153,   153,   153,   153,   153,   153,   153,
     153,   153,   153,   153,   153,   153,   154,   154,   155,   156,
     156,   157,   157,   157,   157,   157,   157,   157,   157,   158,
     159,   159,   160
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     2,     4,     5,     5,     5,     1,     1,     4,
       2,     3,     5,     1,     3,     0,     2,     2,     0,     3,
       1,     2,     4,     1,     1,     3,     4,     5,     3,     1,
       2,     1,     1,     2,     4,     3,     0,     2,     0,     2,
       4,     1,     3,     6,     0,     1,     3,     3,     3,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       5,     5,     9,     6,     5,     7,     2,     1,     4,     6,
       0,     2,     4,     3,     1,     4,     3,     3,     3,     1,
       3,     3,     1,     2,     1,     3,     3,     3,     3,     3,
       3,     1,     3,     3,     1,     3,     3,     3,     1,     2,
       1,     1,     3,     4,     3,     1,     1,     1,     1,     1,
       4,     0,     1,     3,     3,     1,     3,     1,     3,     3,
       3,     0,     8,     2,     4,     0,     2,     3,     3,     1,
       1,     3,     1,     1,     0,     1,     3,     3,     3,     1,
       3,     1,     3,     1,     4,     0,     1,     3,     1,     2,
      10,     1,     3,     3,     1,     1,     0,     2,     0,     1,
       3,     3,     3,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     2,     3,     4,     4,     3,     7,     7,
       4,     4,     4,     4,     4,     4,     1,     5,     3,     0,
       1,     4,     4,     3,     3,     2,     3,     1,     5,     1,
       1,     3,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
      15,     0,     0,     1,   125,     0,    18,    16,     2,     0,
       0,     0,     0,    17,    20,     0,     0,     7,     0,   126,
       0,   125,   132,   133,   123,   129,   130,     0,    21,     0,
      19,    36,     0,     0,     0,   189,   189,     0,     0,     0,
       0,     0,   186,     3,     0,   127,   121,     0,     0,     0,
      24,     0,     0,     0,    23,     0,     0,    44,    38,     0,
       4,    13,     6,   117,     0,     5,     0,     8,     0,     0,
       0,     0,   199,     0,   190,   197,     0,   173,     0,     0,
       0,   101,   109,     0,     0,   105,   106,     0,     0,     0,
       0,    79,    82,    84,    91,    94,    98,   100,   107,   108,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     134,   124,   128,   131,     0,     0,    32,     0,    31,     0,
      29,     0,    22,    41,     0,     0,    45,    37,     0,    35,
       0,     0,     0,     0,    10,   195,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     177,     0,     0,   111,    83,     0,   115,     0,    99,     0,
       0,     0,     0,   174,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   171,
     172,   163,     0,   165,   168,   170,   167,   169,   166,     0,
       0,   135,     0,    25,    33,     0,    28,    30,     0,     0,
       0,     0,     0,    39,     0,    74,     0,     0,     0,     0,
       0,    67,     0,     0,    49,    51,    52,    53,    54,    55,
      58,    59,    56,    57,     0,    14,   118,   143,   119,   120,
     139,   141,     0,     0,   196,     0,     0,   182,   180,   184,
       0,   193,   194,     0,   183,   181,   185,     0,   188,   176,
     112,     0,   104,     0,   114,     0,   102,    77,    78,    80,
      81,    85,    88,    86,    89,    87,    90,    92,    93,    97,
      95,    96,   175,     0,     0,     0,     0,     0,     0,    26,
       0,    42,    47,    46,     0,     0,     0,     0,    70,     0,
       0,     0,    66,     0,    48,     0,     0,     0,   145,     0,
       0,     9,     0,     0,   192,   191,     0,     0,     0,   200,
       0,   111,   110,   116,   103,   187,   164,   137,   138,   136,
       0,   122,   148,    34,    27,    43,     0,     0,     0,     0,
       0,    70,     0,     0,     0,    50,    73,     0,    76,   146,
       0,   140,   142,     0,    11,     0,     0,   198,     0,     0,
     113,   154,   155,    36,   149,    40,     0,     0,     0,    68,
       0,    71,     0,     0,     0,    75,   145,   144,     0,   178,
     202,   201,   179,     0,     0,   151,   156,    60,    64,     0,
       0,     0,    61,     0,     0,   147,    12,    36,    36,     0,
       0,     0,    72,    69,     0,    63,   153,   152,   157,   158,
      65,     0,     0,     0,   159,     0,     0,     0,   158,    62,
     161,   162,   158,   160,     0,   150
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,     1,    18,    65,    66,   232,    60,     2,     7,    15,
      13,    14,    56,   119,   120,   115,   116,    30,    59,   127,
     203,   124,    31,   125,   126,   129,   213,   214,   215,   216,
     217,   218,   219,   220,   221,   222,   330,   331,   223,    89,
     156,    91,    92,    93,    94,    95,    96,    97,    98,   251,
      99,   157,    62,    63,     8,   110,    10,    11,    24,    25,
      42,   190,   191,   229,   230,   231,   340,   321,   322,   376,
     353,   390,   403,   404,   183,    43,    44,    80,    73,    74,
      75,   308,   309
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -293
static const yytype_int16 yypact[] =
{
    -293,    47,    49,  -293,    59,    -1,  -293,  -293,    99,   242,
     108,   165,    76,    -1,  -293,   125,   327,  -293,   121,  -293,
     190,   214,  -293,  -293,   218,  -293,   235,   148,  -293,   230,
    -293,   207,   165,   165,   165,    39,    39,   121,   121,   165,
      37,   165,   204,   270,   252,  -293,  -293,   165,   165,   148,
    -293,   262,   148,   278,  -293,   290,   323,   285,  -293,   306,
    -293,   292,   354,  -293,   355,  -293,   300,   301,    39,    39,
     165,   165,  -293,    10,   299,   302,    12,   270,    68,   356,
     359,    13,  -293,    37,    37,  -293,  -293,    37,   182,   150,
     239,   313,  -293,   257,   279,   184,  -293,  -293,  -293,  -293,
     360,   343,   121,   121,    35,    35,    35,    35,    35,    35,
     165,   218,  -293,  -293,   361,     6,  -293,   330,  -293,   339,
     278,   366,  -293,   367,   368,    -3,  -293,   285,    61,  -293,
      37,   165,   331,   165,  -293,   299,   226,   369,   370,   121,
     121,   121,   121,    39,    39,   317,   121,   121,   121,   121,
    -293,   148,   121,    37,  -293,    41,   225,   312,  -293,    37,
     371,    37,    37,  -293,    37,    37,   160,   160,   160,   160,
     160,   160,   160,   160,   160,   160,   160,   121,    37,  -293,
    -293,  -293,    37,  -293,  -293,  -293,  -293,  -293,  -293,   372,
     253,  -293,   148,  -293,  -293,   148,  -293,  -293,   374,   285,
     148,   285,   375,  -293,   378,  -293,    37,    37,    37,    61,
      -7,  -293,    37,   151,  -293,  -293,  -293,  -293,  -293,  -293,
    -293,  -293,  -293,  -293,     1,   286,  -293,   362,  -293,   322,
    -293,   380,   -58,   379,  -293,    39,    39,   270,   270,   270,
     277,  -293,  -293,   165,   270,   270,   270,   284,  -293,  -293,
       0,   364,  -293,    37,  -293,   244,   275,   313,   313,  -293,
    -293,   279,   279,   279,   279,   279,   279,   184,   184,  -293,
    -293,  -293,  -293,    94,   141,   340,   165,   386,   373,  -293,
     332,  -293,  -293,  -293,   148,   148,   158,   104,   186,    -5,
     382,   388,   286,    61,  -293,    37,    37,   389,   390,   390,
     385,  -293,   165,    37,  -293,  -293,   121,   391,   173,  -293,
     121,    37,  -293,  -293,   276,  -293,  -293,  -293,   322,  -293,
     342,   386,  -293,  -293,  -293,  -293,   392,    61,    61,    37,
     101,   357,    37,    37,   376,  -293,   286,   248,  -293,   395,
     381,  -293,  -293,   394,   286,    22,    37,  -293,   165,    24,
    -293,  -293,  -293,   187,  -293,  -293,   194,    43,     7,  -293,
      61,  -293,    79,   144,    61,  -293,   390,  -293,    37,  -293,
     286,  -293,  -293,   334,   335,  -293,   345,  -293,  -293,    61,
      61,   197,  -293,    37,   198,  -293,   286,   207,   207,    37,
     405,   199,   402,  -293,   163,  -293,  -293,  -293,   286,   165,
    -293,    61,   406,   404,   408,   202,   344,   410,   165,  -293,
    -293,   322,   165,  -293,   409,  -293
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,  -293,
    -293,   411,   -14,   303,  -293,  -293,   310,  -293,  -263,  -293,
    -293,  -122,  -293,  -293,   227,  -293,  -197,   128,  -293,  -293,
    -293,  -293,  -293,  -293,  -293,  -293,    95,  -293,  -293,  -127,
     -36,   200,   -81,  -293,   153,   191,   164,   341,  -293,   116,
    -293,   177,  -293,   304,  -293,  -293,  -293,   412,   384,   393,
     -11,  -293,   156,  -272,   135,  -292,    70,  -293,   117,  -293,
    -293,  -293,  -247,  -293,   220,     8,  -293,    57,   401,   -42,
    -293,  -293,    91
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -77
static const yytype_int16 yytable[] =
{
      26,   224,   154,   318,    90,   204,   339,   290,   293,   301,
     201,   311,   289,    12,   139,   302,   146,   295,   332,   380,
     114,    61,    64,    67,    72,    72,   135,   136,    79,   202,
      79,   140,   141,   147,   148,   113,    26,    26,   117,   102,
     103,   102,   103,   193,   153,    77,    78,     3,   155,   291,
     181,    81,    82,    22,    23,     4,   293,    72,    72,    79,
      79,    83,     9,    68,   161,   162,   182,   296,    84,   297,
      69,   161,   162,   252,   339,   205,   142,   281,   149,   -74,
     378,   -74,   224,   259,   260,   102,   103,     5,     6,   369,
     375,   372,    27,   379,   225,    70,    85,    86,   100,   189,
     150,   241,   242,    87,    16,   161,   162,    88,   206,   207,
     179,   180,   208,    71,   209,   210,   382,   250,   211,   212,
      64,    21,   233,   255,   396,   397,   315,   137,   138,    17,
     356,   357,    72,    72,   411,    22,    23,   248,   359,    29,
      35,    36,   273,   161,   162,    37,   274,   237,   238,   239,
     240,   360,    38,   328,   244,   245,   246,   247,   161,   162,
     249,   413,    50,   381,   293,   414,   224,   384,   161,   162,
     286,   287,   288,   316,    81,    82,   292,    39,   278,    22,
      23,   279,   391,   392,    51,   272,   282,    40,   294,    52,
      53,    84,    54,   304,   305,    41,    81,    82,   327,   383,
     224,   224,    45,   401,   405,   161,   162,   293,   161,   162,
     293,   293,   293,    84,    55,   293,   159,     9,   160,    85,
      86,    46,   161,   162,    72,    72,    87,   161,   162,    48,
      88,   377,   307,   224,   393,   395,   400,   224,   329,   409,
     347,    85,    86,   143,   144,   174,   348,    49,    87,    58,
     161,   162,   224,   224,    19,   175,   176,    20,   234,   336,
     337,    57,   373,   374,   276,   189,   277,   344,   104,    58,
     325,   326,   101,   166,   224,   250,   114,   105,   106,   107,
     108,   109,   167,   168,   169,   170,   171,   102,   103,   161,
     162,   343,   118,   358,   102,   103,   362,   363,   253,   123,
     306,   102,   103,   161,   162,   121,   163,   310,   161,   162,
     370,   314,   161,   162,   345,   365,   143,   144,   349,   261,
     262,   263,   264,   265,   266,   184,   185,   186,   187,   188,
     164,   165,   386,    32,    33,    34,   122,   307,   269,   270,
     271,   -76,   -75,   -76,   -75,   227,   228,   394,   172,   173,
     161,   162,   128,   398,   227,   317,   351,   352,   227,   410,
     130,   257,   258,   267,   268,   131,   133,   132,   151,   134,
     145,   152,   177,   192,   178,   195,   196,   198,   199,   254,
     200,   235,   236,   243,   275,   256,   323,   284,   402,   280,
     285,   299,   300,   298,   320,   303,   312,   402,   333,   324,
     342,   402,   334,   338,   227,   355,   366,   346,   389,   329,
     368,   387,   388,   367,   399,   293,   364,   407,   406,   408,
     412,   335,   415,   197,    28,   194,   361,   350,   283,   158,
     313,   111,   319,    47,   341,   226,   385,    76,   354,   371,
       0,   112
};

static const yytype_int16 yycheck[] =
{
      11,   128,    83,   275,    40,   127,   298,    14,    13,    67,
      13,    11,   209,    14,     4,    73,     4,    16,    23,    12,
      14,    32,    33,    34,    35,    36,    68,    69,    39,    32,
      41,    21,    22,    21,    22,    49,    47,    48,    52,    17,
      18,    17,    18,    37,    31,    37,    38,     0,    84,    56,
      15,    14,    15,    14,    15,     6,    13,    68,    69,    70,
      71,    24,     3,    24,    64,    65,    31,    66,    31,    68,
      31,    64,    65,    32,   366,    14,    66,   199,    66,    66,
      37,    68,   209,   164,   165,    17,    18,    38,    39,    67,
     353,    67,    16,    50,   130,    56,    59,    60,    41,   110,
      32,   143,   144,    66,     5,    64,    65,    70,    47,    48,
     102,   103,    51,    74,    53,    54,    37,   153,    57,    58,
     131,    13,   133,   159,   387,   388,    32,    70,    71,    30,
     327,   328,   143,   144,   406,    14,    15,   151,    37,    14,
      19,    20,   178,    64,    65,    24,   182,   139,   140,   141,
     142,    50,    31,    49,   146,   147,   148,   149,    64,    65,
     152,   408,    14,   360,    13,   412,   293,   364,    64,    65,
     206,   207,   208,    32,    14,    15,   212,    56,   192,    14,
      15,   195,   379,   380,    36,   177,   200,    66,    37,    41,
      42,    31,    44,   235,   236,    74,    14,    15,    40,    55,
     327,   328,    12,    40,   401,    64,    65,    13,    64,    65,
      13,    13,    13,    31,    66,    13,    66,     3,    68,    59,
      60,     7,    64,    65,   235,   236,    66,    64,    65,    11,
      70,    37,   243,   360,    37,    37,    37,   364,    52,    37,
      67,    59,    60,    17,    18,    61,    73,    12,    66,    62,
      64,    65,   379,   380,    12,    71,    72,    15,    32,   295,
     296,    31,    75,    76,    11,   276,    13,   303,    16,    62,
     284,   285,    68,    16,   401,   311,    14,    25,    26,    27,
      28,    29,    25,    26,    27,    28,    29,    17,    18,    64,
      65,   302,    14,   329,    17,    18,   332,   333,    73,    14,
      23,    17,    18,    64,    65,    15,    67,    23,    64,    65,
     346,    67,    64,    65,   306,    67,    17,    18,   310,   166,
     167,   168,   169,   170,   171,   105,   106,   107,   108,   109,
      17,    18,   368,     6,     7,     8,    13,   348,   174,   175,
     176,    66,    66,    68,    68,    14,    15,   383,    69,    70,
      64,    65,    46,   389,    14,    15,    14,    15,    14,    15,
      68,   161,   162,   172,   173,    11,    66,    12,    12,    68,
      68,    12,    12,    12,    31,    45,    37,    11,    11,    67,
      12,    12,    12,    66,    12,    14,    13,    12,   399,    15,
      12,    69,    12,    31,     8,    16,    32,   408,    16,    67,
      15,   412,    14,    14,    14,    13,    11,    16,    63,    52,
      16,    77,    77,    32,     9,    13,    40,    13,    12,    11,
      10,   293,    13,   120,    13,   115,   331,   311,   201,    88,
     253,    47,   276,    21,   299,   131,   366,    36,   321,   348,
      -1,    48
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    79,    85,     0,     6,    38,    39,    86,   132,     3,
     134,   135,    14,    88,    89,    87,     5,    30,    80,    12,
      15,    13,    14,    15,   136,   137,   138,    16,    89,    14,
      95,   100,     6,     7,     8,    19,    20,    24,    31,    56,
      66,    74,   138,   153,   154,    12,     7,   135,    11,    12,
      14,    36,    41,    42,    44,    66,    90,    31,    62,    96,
      84,   138,   130,   131,   138,    81,    82,   138,    24,    31,
      56,    74,   138,   156,   157,   158,   156,   153,   153,   138,
     155,    14,    15,    24,    31,    59,    60,    66,    70,   117,
     118,   119,   120,   121,   122,   123,   124,   125,   126,   128,
     155,    68,    17,    18,    16,    25,    26,    27,    28,    29,
     133,   136,   137,    90,    14,    93,    94,    90,    14,    91,
      92,    15,    13,    14,    99,   101,   102,    97,    46,   103,
      68,    11,    12,    66,    68,   157,   157,   155,   155,     4,
      21,    22,    66,    17,    18,    68,     4,    21,    22,    66,
      32,    12,    12,    31,   120,   118,   118,   129,   125,    66,
      68,    64,    65,    67,    17,    18,    16,    25,    26,    27,
      28,    29,    69,    70,    61,    71,    72,    12,    31,   153,
     153,    15,    31,   152,   152,   152,   152,   152,   152,   138,
     139,   140,    12,    37,    94,    45,    37,    91,    11,    11,
      12,    13,    32,    98,    99,    14,    47,    48,    51,    53,
      54,    57,    58,   104,   105,   106,   107,   108,   109,   110,
     111,   112,   113,   116,   117,   118,   131,    14,    15,   141,
     142,   143,    83,   138,    32,    12,    12,   153,   153,   153,
     153,   157,   157,    66,   153,   153,   153,   153,    90,   153,
     118,   127,    32,    73,    67,   118,    14,   119,   119,   120,
     120,   122,   122,   122,   122,   122,   122,   123,   123,   124,
     124,   124,   153,   118,   118,    12,    11,    13,    90,    90,
      15,    99,    90,   102,    12,    12,   118,   118,   118,   104,
      14,    56,   118,    13,    37,    16,    66,    68,    31,    69,
      12,    67,    73,    16,   157,   157,    23,   138,   159,   160,
      23,    11,    32,   129,    67,    32,    32,    15,   141,   140,
       8,   145,   146,    13,    67,    90,    90,    40,    49,    52,
     114,   115,    23,    16,    14,   105,   118,   118,    14,   143,
     144,   142,    15,   138,   118,   153,    16,    67,    73,   153,
     127,    14,    15,   148,   146,    13,   104,   104,   118,    37,
      50,   114,   118,   118,    40,    67,    11,    32,    16,    67,
     118,   160,    67,    75,    76,    96,   147,    37,    37,    50,
      12,   104,    37,    55,   104,   144,   118,    77,    77,    63,
     149,   104,   104,    37,   118,    37,    96,    96,   118,     9,
      37,    40,   138,   150,   151,   104,    12,    13,    11,    37,
      15,   141,    10,   150,   150,    13
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 159 "readnet-syntax.yy"
    { 
#ifdef WITHFORMULA
F = (formula *) 0 ; 
#endif
}
    break;

  case 3:
#line 164 "readnet-syntax.yy"
    { 
#ifdef WITHFORMULA
F = (yyvsp[(4) - (4)].form);
#endif
}
    break;

  case 4:
#line 169 "readnet-syntax.yy"
    {
	CheckPlace = (yyvsp[(5) - (5)].pl);
#ifdef STUBBORN
	Transitions[0]->StartOfStubbornList = (Transition *) 0;
int i;
	for(i=0;CheckPlace -> PreTransitions[i];i++)
	{
		CheckPlace->PreTransitions[i]->instubborn = true;
		CheckPlace->PreTransitions[i]->NextStubborn = Transitions[0]->StartOfStubbornList;
		Transitions[0]->StartOfStubbornList = CheckPlace->PreTransitions[i];
	}
	Transitions[0]->EndOfStubbornList = LastAttractor = CheckPlace -> PreTransitions[0];
#endif
                }
    break;

  case 5:
#line 183 "readnet-syntax.yy"
    {
	CheckTransition = (yyvsp[(5) - (5)].tr);
#ifdef STUBBORN
	Transitions[0]->EndOfStubbornList = LastAttractor = Transitions[0]->StartOfStubbornList = CheckTransition;
	CheckTransition -> NextStubborn = (Transition *) 0;
	CheckTransition -> instubborn = true;
#endif
	}
    break;

  case 7:
#line 193 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(256);}
    break;

  case 8:
#line 195 "readnet-syntax.yy"
    {
				TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (1)].str));
				if(!TS) yyerror("transition does not exist");
				if(TS -> vars && TS -> vars -> card)
				{
					yyerror("HL transition requires firing mode");
				}
				(yyval.tr) = TS -> transition;
			}
    break;

  case 9:
#line 205 "readnet-syntax.yy"
    {
		   unsigned int i, j,card;
		   fmode * fm;
		   VaSymbol * v;
		   UValue * vl;
		   char ** cc;
		   char ** inst;
		   unsigned int len;
		   for(card=0,fm=(yyvsp[(3) - (4)].fm);fm;fm = fm -> next,card++);
		   if(card != (yyvsp[(1) - (4)].ts) -> vars -> card)
		   {
			yyerror("firing mode incomplete");
		   }
		   cc = new char * [ card + 10];
		   inst= new char * [ card + 10];
		   len = strlen((yyvsp[(1) - (4)].ts)->name) + 4;
		   j=0;
		   for(i=0;i<LocalTable->size;i++)
		   {
			for(VS = (VaSymbol *) (LocalTable -> table[i]);VS; VS = (VaSymbol *) (VS -> next))
			{
				UValue * pl;
				for(fm=(yyvsp[(3) - (4)].fm);fm;fm=fm ->next)
				{	
					if(fm -> v == VS) break;
				}
				if(!fm) yyerror("firing mode incomplete");
				vl = fm -> t -> evaluate();
				pl = VS -> var -> type -> make();
				pl -> assign(vl);
				cc[j] = pl -> text();
				inst[j] = new char [strlen(VS -> name)+strlen(cc[j]) + 20];
				strcpy(inst[j],VS -> name);
				strcpy(inst[j]+strlen(inst[j]),"=");
				strcpy(inst[j]+strlen(inst[j]),cc[j]);
				len += strlen(inst[j]) + 1;
				j++;
			}
		   } 
		   char * llt;
		   llt = new char[len+20];
		   strcpy(llt,(yyvsp[(1) - (4)].ts) -> name);
		   strcpy(llt+strlen(llt),".[");
		   for(j=0;j<card;j++)
		   {
			strcpy(llt + strlen(llt),inst[j]);
			strcpy(llt + strlen(llt),"|");
		   }
		   strcpy(llt + (strlen(llt) - 1),"]");
		   TS = (TrSymbol *) TransitionTable -> lookup(llt);
		   if(!TS) yyerror("transition instance does not exist");
		   if(TS -> vars && TS -> vars -> card)
		   {
			yyerror("HL and LL transition names mixed up");
		   }
		   (yyval.tr) = TS -> transition;
		   }
    break;

  case 10:
#line 263 "readnet-syntax.yy"
    {
			TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (2)].str));
			if(!TS) yyerror("transition does not exist");
			if( ( !(TS -> vars) || TS -> vars -> card == 0))
			{
				yyerror("only HL transitions require firing mode");
			}
			(yyval.ts) = TS;
			LocalTable = TS -> vars;
			}
    break;

  case 11:
#line 274 "readnet-syntax.yy"
    {
			VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(1) - (3)].str));
			if(!VS) yyerror("transition does not have this variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
			{
				yyerror("expression not compatible with transition variable");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> next = (fmode *) 0;
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(3) - (3)].ex);
			}
    break;

  case 12:
#line 286 "readnet-syntax.yy"
    {
			fmode * fm;
			VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(3) - (5)].str));
			if(!VS) yyerror("transition does not have this variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(5) - (5)].ex) -> type)))
			{
				yyerror("expression not compatible with transition variable");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> next = (yyvsp[(1) - (5)].fm);
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(5) - (5)].ex) ;
			for(fm = (yyvsp[(1) - (5)].fm); fm ; fm = fm -> next)
			{
				if(fm -> v == (yyval.fm) -> v)
				{
					yyerror("variable appears twice in firing mode");
				}
			}
			}
    break;

  case 13:
#line 308 "readnet-syntax.yy"
    {
	PS = (PlSymbol *) PlaceTable ->lookup((yyvsp[(1) - (1)].str)); 
	if(!PS) yyerror("Place does not exist");
	if(PS -> sort) yyerror("HL places require instance");
	(yyval.pl) = PS -> place;
	}
    break;

  case 14:
#line 314 "readnet-syntax.yy"
    {
	PS = (PlSymbol *) PlaceTable ->lookup((yyvsp[(1) - (3)].str)); 
	if(!PS) yyerror("Place does not exist");
	if(!(PS -> sort)) yyerror("LL places do not require instance");
	if(!(PS -> sort -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
	{	
		yyerror("place color not compatible to place sort");
	}
	UValue * vl , * pl;
	vl = (yyvsp[(3) - (3)].ex) -> evaluate();
	pl = PS -> sort -> make();
	pl -> assign(vl);
	char * inst;
	inst = pl -> text();
	char * ll;
	ll = new char [strlen(PS -> name) + strlen(inst) + 20];
	strcpy(ll,PS -> name);
	strcpy(ll + strlen(ll),".");
	strcpy(ll + strlen(ll),inst);
	PS = (PlSymbol *) PlaceTable -> lookup(ll);
	if(!PS) yyerror("place instance does not exist");
	if(PS->sort) yyerror("mixed up HL and LL place names");
	(yyval.pl) = PS -> place;
	}
    break;

  case 18:
#line 343 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(1);}
    break;

  case 22:
#line 348 "readnet-syntax.yy"
    {
				// sort symbols are globally visible. A sort entry in the
				// symbol table relates a name to a sort description (UType)

				SoSymbol * s;
				if(s = (SoSymbol *) (GlobalTable -> lookup((yyvsp[(1) - (4)].str))))
				{
					yyerror("sort symbol name already used");
				}
				s = new SoSymbol((yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].t));
			}
    break;

  case 23:
#line 360 "readnet-syntax.yy"
    { (yyval.t) = TheBooType; }
    break;

  case 24:
#line 361 "readnet-syntax.yy"
    {
							// assign an additional name to an existing sort
							SoSymbol * s;
							s = (SoSymbol *) (GlobalTable -> lookup((yyvsp[(1) - (1)].str)));
							if(!s) yyerror("undefined sort name");
							if(s -> kind != so) yyerror("sort name expected");
							(yyval.t) = s -> type;
						}
    break;

  case 25:
#line 369 "readnet-syntax.yy"
    {
						URcList * rl;
						(yyval.t) = new URecType((yyvsp[(2) - (3)].rcl));
						}
    break;

  case 26:
#line 373 "readnet-syntax.yy"
    {
						// index type must be scalar
						if((yyvsp[(2) - (4)].t) -> tag != boo && (yyvsp[(2) - (4)].t) ->tag != num && (yyvsp[(2) - (4)].t) -> tag != enu)
						{
							yyerror("non-scalar type as index of array");
						}
						(yyval.t) = new UArrType((yyvsp[(2) - (4)].t),(yyvsp[(4) - (4)].t));
						}
    break;

  case 27:
#line 381 "readnet-syntax.yy"
    {
				// integer interval
				unsigned int l,r;
				sscanf((yyvsp[(2) - (5)].str),"%u",&l);
				sscanf((yyvsp[(4) - (5)].str),"%u",&r);
				{
					if(l > r) yyerror("negative range in integer type");
				}
				(yyval.t) = new UNumType(l,r);
			}
    break;

  case 28:
#line 391 "readnet-syntax.yy"
    {
					(yyval.t) = new UEnuType((yyvsp[(2) - (3)].el));
					}
    break;

  case 30:
#line 396 "readnet-syntax.yy"
    { 
					(yyvsp[(1) - (2)].el) -> next = (yyvsp[(2) - (2)].el);
					(yyval.el) = (yyvsp[(1) - (2)].el);
				 }
    break;

  case 31:
#line 401 "readnet-syntax.yy"
    {
			EnSymbol * e;
			UEnList * eel;
			e = (EnSymbol *) GlobalTable -> lookup((yyvsp[(1) - (1)].str));
			if(e) yyerror("element name of enumeration already used");
			e = new EnSymbol((yyvsp[(1) - (1)].str));
			eel = new UEnList;
			eel -> sy = e;
			eel -> next = (UEnList *) 0;
			(yyval.el) = eel;
			}
    break;

  case 33:
#line 415 "readnet-syntax.yy"
    {
						(yyvsp[(2) - (2)].rcl) -> next = (yyvsp[(1) - (2)].rcl);
						(yyval.rcl) = (yyvsp[(2) - (2)].rcl);
					}
    break;

  case 34:
#line 420 "readnet-syntax.yy"
    {
						RcSymbol * r;
						URcList * rl;
						r = (RcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
						if(r) yyerror("record component name already used");
						r = new RcSymbol((yyvsp[(1) - (4)].str),(yyvsp[(3) - (4)].t));
						rl = new URcList;
						rl -> next = (URcList *) 0;
						rl -> sy = r;
						rl -> ty = (yyvsp[(3) - (4)].t);
						(yyval.rcl) = rl;
					}
    break;

  case 35:
#line 435 "readnet-syntax.yy"
    {
							(yyvsp[(1) - (3)].fu) -> body = (yyvsp[(3) - (3)].stm);
							(yyvsp[(1) - (3)].fu) -> localsymb = LocalTable;
						}
    break;

  case 40:
#line 442 "readnet-syntax.yy"
    {
							IdList * il;
							for(il = (yyvsp[(1) - (4)].idl);il;il=il->next)
							{	
								VaSymbol * v;
								UVar * vvv;
								if(v = (VaSymbol *) (LocalTable -> lookup(il -> name)))
								{
									yyerror("variable name already used");
								}
								vvv = new UVar((yyvsp[(3) - (4)].t));
								v = new VaSymbol(il -> name,vvv);
							}
							}
    break;

  case 41:
#line 457 "readnet-syntax.yy"
    {
				(yyval.idl) = new IdList;
				(yyval.idl) -> name = (yyvsp[(1) - (1)].str);
				(yyval.idl) -> next = (IdList *) 0;
				}
    break;

  case 42:
#line 462 "readnet-syntax.yy"
    {
				(yyval.idl) = new IdList;
				(yyval.idl) -> name = (yyvsp[(1) - (3)].str);
				(yyval.idl) -> next = (yyvsp[(3) - (3)].idl);
			}
    break;

  case 43:
#line 469 "readnet-syntax.yy"
    {
			FcSymbol * fs;
			UFunction * f;
			fs = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (6)].str));
			if(fs)
			{
				yyerror("function name already used");
			}
			CurrentFunction = f = new UFunction();
			fs = new FcSymbol((yyvsp[(1) - (6)].str),f);
			f -> type = (yyvsp[(6) - (6)].t);
			f -> localsymb = LocalTable;
			f -> result = (UValueList *) 0;
			f -> resultstack = (UResultList *) 0;
			f -> arity = LocalTable -> card;
			f -> formalpar = new UVar * [f -> arity +5];
			int i;
			i = 0;
			for(int j = 0; j < LocalTable -> size; j++)
			{
				Symbol * s;
				for(s = LocalTable -> table[j]; s; s = s -> next)
				{	
					f -> formalpar[(f->arity -1) -i++] = ((VaSymbol *) s) -> var;
				}
			}
				
				(yyval.fu) = f;
		}
    break;

  case 47:
#line 500 "readnet-syntax.yy"
    {
		IdList * il;
		for(il = (yyvsp[(1) - (3)].idl); il; il = il -> next)
		{
								VaSymbol * v;
								UVar * vvv;
								if(v = (VaSymbol *) (LocalTable -> lookup(il -> name)))
								{
									yyerror("variable name already used");
								}
								vvv = new UVar((yyvsp[(3) - (3)].t));
								v = new VaSymbol(il -> name,vvv);
			
		}
		}
    break;

  case 48:
#line 516 "readnet-syntax.yy"
    { (yyval.stm) = (yyvsp[(2) - (3)].stm); }
    break;

  case 50:
#line 519 "readnet-syntax.yy"
    { 
										   UStatement * s;
										   s = new USequenceStatement;
                                          ((USequenceStatement * ) s) -> first = (yyvsp[(1) - (3)].stm);
                                          ((USequenceStatement *) s) -> second = (yyvsp[(3) - (3)].stm);
											(yyval.stm) = s;
					}
    break;

  case 60:
#line 537 "readnet-syntax.yy"
    {
		if((yyvsp[(2) - (5)].ex) -> type -> tag != boo)
		{
			yyerror("while condition must be boolean");
		}
		(yyval.stm) = new UWhileStatement;
		((UWhileStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (5)].ex);
		((UWhileStatement *) (yyval.stm)) -> body = (yyvsp[(4) - (5)].stm);
		}
    break;

  case 61:
#line 547 "readnet-syntax.yy"
    {
		if((yyvsp[(4) - (5)].ex) -> type -> tag != boo)
		{
			yyerror("while condition must be boolean");
		}
		(yyval.stm) = new URepeatStatement;
		((URepeatStatement *) (yyval.stm)) -> cond = (yyvsp[(4) - (5)].ex);
		((URepeatStatement *) (yyval.stm)) -> body = (yyvsp[(2) - (5)].stm);
		}
    break;

  case 62:
#line 557 "readnet-syntax.yy"
    {
		VaSymbol * v;
		v = (VaSymbol *) LocalTable -> lookup((yyvsp[(2) - (9)].str));
		if(!v) yyerror("loop variable not declared");
		(yyval.stm) = new UForStatement;
		((UForStatement *) (yyval.stm)) -> var = v -> var;
		if(! ( v->var->type -> iscompatible((yyvsp[(4) - (9)].ex) -> type)))
		{
			yyerror("initial expression of for statement not compatible to counter variable");
		}
		if(! ( v->var->type -> iscompatible((yyvsp[(6) - (9)].ex) -> type)))
		{
			yyerror("exit expression of for statement not compatible to counter variable");
		}
		((UForStatement *) (yyval.stm)) -> init = (yyvsp[(4) - (9)].ex);
		((UForStatement *) (yyval.stm)) -> finit = (yyvsp[(6) - (9)].ex);
		((UForStatement *) (yyval.stm)) -> body = (yyvsp[(8) - (9)].stm);
		}
    break;

  case 63:
#line 576 "readnet-syntax.yy"
    {
			VaSymbol * v;
			v = (VaSymbol *) LocalTable -> lookup((yyvsp[(3) - (6)].str));
			if(!v) yyerror("loop variable not declared");
			(yyval.stm) = new UForallStatement;
			((UForallStatement *) (yyval.stm)) -> var = v -> var;
			((UForallStatement *) (yyval.stm)) -> body = (yyvsp[(5) - (6)].stm);
			}
    break;

  case 64:
#line 585 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (5)].ex) -> type -> tag != boo)
			{
				yyerror("condition in if statement must be boolean");
			}
			(yyval.stm) = new UConditionalStatement;
			((UConditionalStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (5)].ex);
			((UConditionalStatement *) (yyval.stm)) -> yes = (yyvsp[(4) - (5)].stm);
			((UConditionalStatement *) (yyval.stm)) -> no = new UNopStatement;
			}
    break;

  case 65:
#line 595 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (7)].ex) -> type -> tag != boo)
			{
				yyerror("condition in if statement must be boolean");
			}
			(yyval.stm) = new UConditionalStatement;
			((UConditionalStatement *) (yyval.stm)) -> cond = (yyvsp[(2) - (7)].ex);
			((UConditionalStatement *) (yyval.stm)) -> yes = (yyvsp[(4) - (7)].stm);
			((UConditionalStatement *) (yyval.stm)) -> no = (yyvsp[(6) - (7)].stm);
			}
    break;

  case 66:
#line 606 "readnet-syntax.yy"
    {
		   if(!((yyvsp[(2) - (2)].ex) -> type -> iscompatible(CurrentFunction -> type)))
		   {
			yyerror("returned value incompatible to function type");
		   }
		   (yyval.stm) = new UReturnStatement;
		   ((UReturnStatement *) (yyval.stm)) -> fct = CurrentFunction;
		   ((UReturnStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (2)].ex);
		   }
    break;

  case 67:
#line 616 "readnet-syntax.yy"
    {
			(yyval.stm) = new UExitStatement;
			((UExitStatement *) (yyval.stm)) -> fct = CurrentFunction;
			 }
    break;

  case 68:
#line 621 "readnet-syntax.yy"
    {
		unsigned int crd;
		case_list * l;
		for(l = (yyvsp[(3) - (4)].cl),crd = 0; l; l = l -> next,crd++)
		{
			if(!((yyvsp[(2) - (4)].ex) -> type -> iscompatible(l -> exp -> type)))
			{
				yyerror("case item incompatible to case expression");
			}
	    	}
		(yyval.stm) = new UCaseStatement;
		((UCaseStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (4)].ex);
		((UCaseStatement *) (yyval.stm)) -> cond = new UExpression * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> yes = new UStatement * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> def = new UNopStatement;
		for(l=(yyvsp[(3) - (4)].cl),crd=0; l; l = l -> next,crd++)
		{	
			((UCaseStatement *) (yyval.stm)) -> cond[crd] = l -> exp;
			((UCaseStatement *) (yyval.stm)) -> yes[crd] = l -> stm;
		}
		((UCaseStatement *) (yyval.stm)) -> card = crd;
		}
    break;

  case 69:
#line 643 "readnet-syntax.yy"
    {
		unsigned int crd;
		case_list * l;
		for(l = (yyvsp[(3) - (6)].cl),crd = 0; l; l = l -> next,crd++)
		{
			if(!((yyvsp[(2) - (6)].ex) -> type -> iscompatible(l -> exp -> type)))
			{
				yyerror("case item incompatible to case expression");
			}
	    	}
		(yyval.stm) = new UCaseStatement;
		((UCaseStatement *) (yyval.stm)) -> exp = (yyvsp[(2) - (6)].ex);
		((UCaseStatement *) (yyval.stm)) -> cond = new UExpression * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> yes = new UStatement * [crd + 10];
		((UCaseStatement *) (yyval.stm)) -> def = (yyvsp[(5) - (6)].stm);
		for(l=(yyvsp[(3) - (6)].cl),crd=0; l; l = l -> next,crd++)
		{	
			((UCaseStatement *) (yyval.stm)) -> cond[crd] = l -> exp;
			((UCaseStatement *) (yyval.stm)) -> yes[crd] = l -> stm;
		}
		((UCaseStatement *) (yyval.stm)) -> card = crd;
		}
    break;

  case 70:
#line 666 "readnet-syntax.yy"
    { (yyval.cl) = (case_list *) 0;}
    break;

  case 71:
#line 667 "readnet-syntax.yy"
    {(yyvsp[(1) - (2)].cl) -> next = (yyvsp[(2) - (2)].cl); (yyval.cl) = (yyvsp[(1) - (2)].cl);}
    break;

  case 72:
#line 669 "readnet-syntax.yy"
    { (yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(2) - (4)].ex);
					(yyval.cl) -> stm = (yyvsp[(4) - (4)].stm);
					(yyval.cl) -> next = (case_list *) 0;
					}
    break;

  case 73:
#line 675 "readnet-syntax.yy"
    {
		if(!((yyvsp[(1) - (3)].lval) -> type -> iscompatible((yyvsp[(3) - (3)].ex)->type)))
		{	
			yyerror("incompatible types in assignment");
		}	
		(yyval.stm) = new UAssignStatement;
		((UAssignStatement *) (yyval.stm)) -> left = (yyvsp[(1) - (3)].lval);
		((UAssignStatement *) (yyval.stm)) -> right = (yyvsp[(3) - (3)].ex);
		}
    break;

  case 74:
#line 685 "readnet-syntax.yy"
    {
		VaSymbol * v;
		v = (VaSymbol *) (LocalTable -> lookup((yyvsp[(1) - (1)].str)));
		if(!v) yyerror("variable not defined");
		(yyval.lval) = new UVarLVal;
		((UVarLVal*) (yyval.lval)) -> var = v -> var;
		(yyval.lval) -> type = ((UVarLVal *) (yyval.lval)) -> var -> type;
		}
    break;

  case 75:
#line 693 "readnet-syntax.yy"
    {
		if((yyvsp[(1) - (4)].lval) -> type -> tag != arr)
		{
			yyerror("component of something not an array referenced");
		}
		if(((yyvsp[(3) - (4)].ex) -> type -> tag != boo) && ((yyvsp[(3) - (4)].ex) -> type -> tag != num) && ((yyvsp[(3) - (4)].ex) -> type -> tag != enu))
		{
			yyerror("non-scalar expression for array index");
		}
		(yyval.lval) = new UArrayLVal;
		(yyval.lval) -> type = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> component;
		((UArrayLVal *) (yyval.lval)) -> indextype = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> index;
		((UArrayLVal *) (yyval.lval)) -> parent = (yyvsp[(1) - (4)].lval);
		((UArrayLVal *) (yyval.lval)) -> idx = (yyvsp[(3) - (4)].ex);
		}
    break;

  case 76:
#line 708 "readnet-syntax.yy"
    {
			RcSymbol *r;
			r = (RcSymbol *) (GlobalTable -> lookup((yyvsp[(3) - (3)].str)));
			if((!r) || (r -> kind != rc))
			{
				yyerror("record component unknown");
			}
			if((yyvsp[(1) - (3)].lval) -> type -> tag != rec)
			{
				yyerror("component of something not a record referenced");
			}
			if(r -> index >= ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> card ||(r -> type != ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r->index]))
			{
				yyerror("record type does not have such component");
			}
			(yyval.lval) = new URecordLVal;
			(yyval.lval) -> type = ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r -> index];
			((URecordLVal *) (yyval.lval)) -> parent = (yyvsp[(1) - (3)].lval);
			((URecordLVal *) (yyval.lval)) -> offset = r -> index;
		}
    break;

  case 77:
#line 729 "readnet-syntax.yy"
    {
				UDivExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UDivExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 78:
#line 741 "readnet-syntax.yy"
    {
				USubExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new USubExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 80:
#line 755 "readnet-syntax.yy"
    {
				UMulExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UMulExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 81:
#line 767 "readnet-syntax.yy"
    {
				UAddExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, boo))
				{
					yyerror("boolean operator applied to non-boolean operands");
				}
				e = new UAddExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 83:
#line 781 "readnet-syntax.yy"
    {
				UNegExpression * e;
				if(!deep_compatible((yyvsp[(2) - (2)].ex) -> type,boo))
				{
					yyerror("boolean operator applied to non-boolean operand");
				}
				e = new UNegExpression;
				e -> left = (yyvsp[(2) - (2)].ex);
				e -> type = (yyvsp[(2) - (2)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 85:
#line 794 "readnet-syntax.yy"
    {
				UEqualExpression * e;
				e = new UEqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 86:
#line 802 "readnet-syntax.yy"
    {
				UGreaterthanExpression * e;
				e = new UGreaterthanExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 87:
#line 810 "readnet-syntax.yy"
    {
				ULessthanExpression * e;
				e = new ULessthanExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 88:
#line 818 "readnet-syntax.yy"
    {
				UGreatereqqualExpression * e;
				e = new UGreatereqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 89:
#line 826 "readnet-syntax.yy"
    {
				ULesseqqualExpression * e;
				e = new ULesseqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 90:
#line 834 "readnet-syntax.yy"
    {
				UUneqqualExpression * e;
				e = new UUneqqualExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = TheBooType;
				(yyval.ex) = e;
				}
    break;

  case 92:
#line 844 "readnet-syntax.yy"
    {
				UAddExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UAddExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 93:
#line 856 "readnet-syntax.yy"
    {
				USubExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new USubExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 95:
#line 870 "readnet-syntax.yy"
    {
				UMulExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UMulExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 96:
#line 882 "readnet-syntax.yy"
    {
				UDivExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UDivExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 97:
#line 894 "readnet-syntax.yy"
    {
				UModExpression * e;
				if(!deep_compatible((yyvsp[(1) - (3)].ex) -> type,(yyvsp[(3) - (3)].ex) -> type, num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UModExpression;
				e -> left = (yyvsp[(1) - (3)].ex);
				e -> right = (yyvsp[(3) - (3)].ex);
				e -> type = (yyvsp[(1) - (3)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 99:
#line 908 "readnet-syntax.yy"
    {
				UNegExpression * e;
				if(!deep_compatible((yyvsp[(2) - (2)].ex) -> type,num))
				{
					yyerror("integer operator applied to non-integer operands");
				}
				e = new UNegExpression;
				e -> left = (yyvsp[(2) - (2)].ex);
				e -> type = (yyvsp[(2) - (2)].ex) -> type;
				(yyval.ex) = e;
				}
    break;

  case 101:
#line 921 "readnet-syntax.yy"
    {
		Symbol * s;
		s = LocalTable -> lookup((yyvsp[(1) - (1)].str));
		if(s)
		{
			// s is local variable

			VaSymbol * v;
			ULvalExpression * e;
			ULVal * l;
			v = (VaSymbol *) s;
			l = new UVarLVal;
			((UVarLVal *) l) -> var = v -> var;
			((UVarLVal *) l) -> type = ((UVarLVal *) l) -> var -> type;
			e = new ULvalExpression;
			e -> type = l -> type;
			e -> lval = l;
			(yyval.ex) = e;
		}
		else
		{
			// try global symbol
			EnSymbol *n;
			UEnuconstantExpression * e;
			s = GlobalTable -> lookup((yyvsp[(1) - (1)].str));
			if(!s) 
			{
				printf((yyvsp[(1) - (1)].str));
				yyerror("identifier not defined");
			}
			if(s->kind != en) yyerror("identifier of wrong kind");
			n = (EnSymbol *) s;
			e = new UEnuconstantExpression;
			e -> type = n -> type;
			e -> nu = n -> ord;
			(yyval.ex) = e;
		}
		}
    break;

  case 102:
#line 959 "readnet-syntax.yy"
    {
			RcSymbol *r;
			URecordLVal * l;
			ULvalExpression * e;
			r = (RcSymbol *) (GlobalTable -> lookup((yyvsp[(3) - (3)].str)));
			if((!r) || (r -> kind != rc))
			{
				yyerror("record component unknown");
			}
			if((yyvsp[(1) - (3)].lval) -> type -> tag != rec)
			{
				yyerror("component of something not a record referenced");
			}
			if(r -> index >= ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> card ||(r -> type != ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r->index]))
			{
				yyerror("record type does not have this component");
			}
			l = new URecordLVal;
			l -> type = ((URecType *) ((yyvsp[(1) - (3)].lval) -> type)) -> component[r -> index];
			l -> parent = (yyvsp[(1) - (3)].lval);
			l -> offset = r -> index;
			e = new ULvalExpression;
			e -> type = l -> type;
			e -> lval = l;
			(yyval.ex) = e;
		}
    break;

  case 103:
#line 985 "readnet-syntax.yy"
    {
		UArrayLVal * a;
		ULvalExpression * e;
		if((yyvsp[(1) - (4)].lval) -> type -> tag != arr)
		{
			yyerror("component of something not an array referenced");
		}
		if(((yyvsp[(3) - (4)].ex) -> type -> tag != boo) && ((yyvsp[(3) - (4)].ex) -> type -> tag != num) && ((yyvsp[(3) - (4)].ex) -> type -> tag != enu))
		{
			yyerror("non-scalar expression for array index");
		}
		a = new UArrayLVal;
		a -> type = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> component;
		a -> parent = (yyvsp[(1) - (4)].lval);
		a -> indextype = ((UArrType *) ((yyvsp[(1) - (4)].lval) -> type)) -> index;
		a -> idx = (yyvsp[(3) - (4)].ex);
		e = new ULvalExpression;
		e -> type = a -> type;
		e -> lval = a;
		(yyval.ex) =e;
		}
    break;

  case 104:
#line 1006 "readnet-syntax.yy"
    {(yyval.ex) = (yyvsp[(2) - (3)].ex);}
    break;

  case 105:
#line 1007 "readnet-syntax.yy"
    {
		(yyval.ex) = new UTrueExpression;
		(yyval.ex) -> type = TheBooType;
		}
    break;

  case 106:
#line 1011 "readnet-syntax.yy"
    {
		(yyval.ex) = new UFalseExpression;
		(yyval.ex) -> type = TheBooType;
		}
    break;

  case 109:
#line 1017 "readnet-syntax.yy"
    {(yyval.ex) = new UIntconstantExpression;
			 sscanf((yyvsp[(1) - (1)].str),"%u",&(((UIntconstantExpression *) (yyval.ex)) -> nu)); 
			 (yyval.ex) -> type = TheNumType;}
    break;

  case 110:
#line 1021 "readnet-syntax.yy"
    {
					UCallExpression * e;
					case_list * c;
					FcSymbol * f;
					int i;
					f = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
					if(!f) yyerror("undefined function called");
					e = new UCallExpression;
					e -> fct = f -> function;
					e -> type = f -> function -> type;
					e -> currentpar = new UExpression * [f -> function -> arity + 10];
					for(i = 0,c=(yyvsp[(3) - (4)].cl); i < f->  function -> arity; i++)
					{
						if(!c) yyerror("too few arguments to function");
						e -> currentpar[i] = c -> exp;
						if(!(c -> exp -> type -> iscompatible(f -> function -> formalpar[i]->type)))
						{
							yyerror("type mismatch in call parameter");
						}
						c = c -> next;
					}
					if(c) yyerror("to many arguments to function");
					(yyval.ex) = e;
				}
    break;

  case 111:
#line 1046 "readnet-syntax.yy"
    {(yyval.cl) = (case_list *) 0;}
    break;

  case 112:
#line 1047 "readnet-syntax.yy"
    {
					(yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(1) - (1)].ex);
					(yyval.cl) -> next = (case_list *) 0;
				}
    break;

  case 113:
#line 1052 "readnet-syntax.yy"
    {
					(yyval.cl) = new case_list;
					(yyval.cl) -> exp = (yyvsp[(1) - (3)].ex);
					(yyval.cl) -> next = (yyvsp[(3) - (3)].cl);
				}
    break;

  case 114:
#line 1058 "readnet-syntax.yy"
    {
					UNumType * it;
					UArrType * at;
					UType * ct;
					unsigned int h;
					int i;
					case_list * c;
					UArrayExpression * e;

					for(c=(yyvsp[(2) - (3)].cl),h=0;c;c = c -> next,h++);
					it = new UNumType(1,h);
					ct = (yyvsp[(2) - (3)].cl) -> exp -> type;
					at = new UArrType(it,ct);
					e = new UArrayExpression;
					e -> type = at;
					e -> card = h;
					e -> cont = new UExpression * [h+10];
					for(i = 0,c = (yyvsp[(2) - (3)].cl); i < h; i++,c = c -> next)
					{
						e -> cont[i] = c -> exp;
						if(!(ct -> iscompatible(c -> exp -> type)))
						{
							yyerror("incompatible types in array value");
						}

					}
					(yyval.ex) = e;
				}
    break;

  case 115:
#line 1087 "readnet-syntax.yy"
    {
				(yyval.cl) = new case_list;
				(yyval.cl) ->exp = (yyvsp[(1) - (1)].ex);
				(yyval.cl) -> next = (case_list *) 0;
			}
    break;

  case 116:
#line 1092 "readnet-syntax.yy"
    {
				(yyval.cl) = new case_list;
				(yyval.cl) -> next = (yyvsp[(3) - (3)].cl);
				(yyval.cl) -> exp = (yyvsp[(1) - (3)].ex);
			}
    break;

  case 119:
#line 1101 "readnet-syntax.yy"
    {
 unsigned int i;
  PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
  if(!PS)
    {
      yyerror("place does not exist");
    }
  if(PS -> sort)
  {
	// HL place, number nicht erlaubt
	yyerror("markings of high level places must be term expressions");
  }
  else
  {
  // LL place, number ist als Anzahl zu interpretieren
  sscanf((yyvsp[(3) - (3)].str),"%u",&i);
  PS->place->target_marking += i;
  }
 }
    break;

  case 120:
#line 1120 "readnet-syntax.yy"
    {
				char * inst, * ll;
				UTermList * tl;
				UValueList * vl, * currentvl;
				UValue * pv;
				PlSymbol * PSI;
				PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
				if(!PS)
				{
					yyerror("place does not exist");
				}
				if(!PS -> sort)
				{	
					yyerror("multiterm expression not allowed for low level places");
				}
				pv = PS -> sort -> make();
				for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next) // do for all mt components
				{
					// check type compatibility
					if(!(PS -> sort -> iscompatible(tl -> t -> type)))
					{
						yyerror("marking expression not compatible to sort of place");
					}
					vl = tl -> t -> evaluate();
					for(currentvl = vl; currentvl;currentvl = currentvl -> next)
					{
						pv -> assign(currentvl -> val); // type adjustment
						inst = pv -> text();
						ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
						strcpy(ll,(yyvsp[(1) - (3)].str));
						strcpy(ll + strlen((yyvsp[(1) - (3)].str)),".");
						strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
						PSI = (PlSymbol *) PlaceTable -> lookup(ll); 
						if(!PSI)
						{
							yyerror("place instance does not exist");
						}
						PSI -> place -> target_marking += tl -> mult;
					}
				}
			}
    break;

  case 121:
#line 1162 "readnet-syntax.yy"
    {LocalTable = (SymbolTab *) 0;}
    break;

  case 122:
#line 1162 "readnet-syntax.yy"
    {
  unsigned int i,h,j;
  Symbol * ss;
  // Create array of places
  Places = new Place * [PlaceTable -> card+10];
  CurrentMarking = new unsigned int [PlaceTable -> card+10];
  i = 0;
  for(h=0;h<PlaceTable -> size;h++)
    {
      for(ss= PlaceTable -> table[h];ss;ss = ss -> next)
	{
	  if(!(((PlSymbol *) ss) -> sort))
	  {
		  Places[i++] = ((PlSymbol *) ss) -> place;
	  }
	}
    }
	PlaceTable->card = i;
  // Create array of transitions 
  Transitions = new Transition * [TransitionTable -> card+10];
  i = 0;
  for(h=0;h<TransitionTable -> size;h++)
    {
      for(ss = TransitionTable -> table[h];ss;ss = ss -> next)
	{
	  if(!(((TrSymbol *) ss) -> vars))
	  {
		  Transitions[i++] = ((TrSymbol *) ss) -> transition;
	  }
	}
    }
	TransitionTable->card = i;
  // Create arc list of places pass 1 (count nr of arcs)
  for(i = 0; i < TransitionTable -> card;i++)
    {
      for(j=0;j < Transitions[i]->NrOfArriving;j++)
	{
	  Transitions[i]->ArrivingArcs[j]->pl->NrOfLeaving++;
	}
      for(j=0;j < Transitions[i]->NrOfLeaving;j++)
	{
	  Transitions[i]->LeavingArcs[j]->pl->NrOfArriving++;
	}
    }
  // pass 2 (allocate arc arrays)
  for(i=0;i<PlaceTable -> card;i++)
    {
      Places[i]->ArrivingArcs = new Arc * [Places[i]->NrOfArriving+10];
      Places[i]->NrOfArriving = 0;
      Places[i]->LeavingArcs = new Arc * [Places[i]->NrOfLeaving+10];
      Places[i]->NrOfLeaving = 0;
    }
  // pass 3 (fill in arcs)
  for(i=0;i<TransitionTable -> card;i++)
    {
      for(j=0;j < Transitions[i]->NrOfLeaving;j++)
	{
	  Place * pl;
	  pl = Transitions[i]->LeavingArcs[j]->pl;
	  pl->ArrivingArcs[pl->NrOfArriving] = Transitions[i]->LeavingArcs[j];
	  pl->NrOfArriving ++;
	}
      for(j=0;j < Transitions[i]->NrOfArriving;j++)
	{
	  Place * pl;
	  pl = Transitions[i]->ArrivingArcs[j]->pl;
	  pl->LeavingArcs[pl->NrOfLeaving] = Transitions[i]->ArrivingArcs[j];
	  pl->NrOfLeaving ++;
	}
    }
    for(i=0;i<TransitionTable->card;i++)
    {
#ifdef STUBBORN
      Transitions[i] -> mustbeincluded = Transitions[i]->conflicting;
#if defined(EXTENDED) && defined(MODELCHECKING)
	Transitions[i]->lstfired = new unsigned int [10];
	Transitions[i]->lstdisabled = new unsigned int [10];
#endif
#endif
    }
#if defined(EXTENDED) && defined(MODELCHECKING)
	formulaindex = 0;
	currentdfsnum = 0;
#endif
  // initialize places
#ifdef STUBBORN
  for(i= 0;i < PlaceTable -> card;i++) Places[i]->initialize();
#endif
  Transitions[0]-> StartOfEnabledList = Transitions[0];
// The following pieces of code initialize static attractor sets for
// various problems.
#ifdef BOUNDEDNET
#ifdef STUBBORN
	// initialize list of pumping transitions
	LastAttractor = (Transition*)0;
	int p,c,a; // produced, consumed tokens, current arc
	for(i=0;i< TransitionTable -> card;i++)
	{
		// count produced tokens
		for(a=0,p=0;a<Transitions[i]->NrOfLeaving;a++)
		{
			p += Transitions[i]->LeavingArcs[a] -> Multiplicity;
		}
		// count consumed tokens
		for(a=0,c=0;a<Transitions[i]->NrOfArriving;a++)
		{
			c += Transitions[i]->ArrivingArcs[a]->Multiplicity;
		}
		if(p > c)
		{
			Transitions[i]->instubborn = true;
			if(LastAttractor)
			{
				Transitions[i]->NextStubborn = 
					Transitions[i]->StartOfStubbornList;
				Transitions[i]->StartOfStubbornList = Transitions[i];
			}
			else
			{
				Transitions[i]->StartOfStubbornList = LastAttractor = Transitions[i];
				Transitions[i]-> NextStubborn = (Transition *) 0;
			}
		}
	}
		
#endif
#endif
}
    break;

  case 125:
#line 1294 "readnet-syntax.yy"
    { CurrentCapacity = CAPACITY;}
    break;

  case 126:
#line 1295 "readnet-syntax.yy"
    {CurrentCapacity = 1;}
    break;

  case 127:
#line 1296 "readnet-syntax.yy"
    { sscanf((yyvsp[(2) - (3)].str),"%u",&CurrentCapacity);}
    break;

  case 130:
#line 1301 "readnet-syntax.yy"
    {
			 if(PlaceTable -> lookup((yyvsp[(1) - (1)].str)))
			 {
			   yyerror("Place name used twice");
		     }
			 P = new Place((yyvsp[(1) - (1)].str));
		     PS = new PlSymbol(P);
			 PS -> sort = (UType *) 0;
			 P -> capacity = CurrentCapacity;
			 P -> nrbits = CurrentCapacity > 0 ? logzwo(CurrentCapacity) : 32;
		}
    break;

  case 131:
#line 1312 "readnet-syntax.yy"
    {
			// high level place: unfold to all instances
			char * c;
			if(PlaceTable -> lookup((yyvsp[(1) - (3)].str)))
			{
				yyerror("Place name used twice");
			}
			c = new char [strlen((yyvsp[(1) - (3)].str))+10];
			strcpy(c,(yyvsp[(1) - (3)].str));
			PS =  new PlSymbol(c);
			PS -> sort = (yyvsp[(3) - (3)].t);
			UValue * v;
			v = (yyvsp[(3) - (3)].t) -> make();
			do
			{
				char * lowlevelplace;
				char * lowtag;
				lowtag = v -> text();
				lowlevelplace = new char [ strlen(c) + strlen(lowtag) + 20];
				strcpy(lowlevelplace,c);
				strcpy(lowlevelplace + strlen(c), ".");
				strcpy(lowlevelplace + strlen(c) + 1, lowtag);
				if(PlaceTable -> lookup(lowlevelplace))
				{
					yyerror("Place instance name already used");
				}
				P = new Place(lowlevelplace);
				P -> capacity = CurrentCapacity;
				P -> nrbits = CurrentCapacity > 0 ? logzwo(CurrentCapacity) : 32;
				PS = new PlSymbol(P);
				PS -> sort = (UType *) 0;
				(*v)++;
			} while(!(v -> isfirst()));
			}
    break;

  case 132:
#line 1347 "readnet-syntax.yy"
    { (yyval.str) = (yyvsp[(1) - (1)].str);}
    break;

  case 133:
#line 1348 "readnet-syntax.yy"
    {(yyval.str) = (yyvsp[(1) - (1)].str); }
    break;

  case 137:
#line 1354 "readnet-syntax.yy"
    {
  unsigned int i;
  PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
  if(!PS)
    {
      yyerror("place does not exist");
    }
  if(PS -> sort)
  {
	// HL place, number nicht erlaubt
	yyerror("markings of high level places must be term expressions");
  }
  else
  {
  // LL place, number ist als Anzahl zu interpretieren
  sscanf((yyvsp[(3) - (3)].str),"%u",&i);
  *(PS->place) += i;
  }
 }
    break;

  case 138:
#line 1373 "readnet-syntax.yy"
    {
				char * inst, * ll;
				UTermList * tl;
				UValueList * vl, * currentvl;
				UValue * pv;
				PlSymbol * PSI;
				PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
				if(!PS)
				{
					yyerror("place does not exist");
				}
				if(!PS -> sort)
				{	
					yyerror("multiterm expression not allowed for low level places");
				}
				pv = PS -> sort -> make();
				for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next) // do for all mt components
				{
					// check type compatibility
					if(!(PS -> sort -> iscompatible(tl -> t -> type)))
					{
						yyerror("marking expression not compatible to sort of place");
					}
					vl = tl -> t -> evaluate();
					for(currentvl = vl; currentvl;currentvl = currentvl -> next)
					{
						pv -> assign(currentvl -> val); // type adjustment
						inst = pv -> text();
						ll = new char [strlen((yyvsp[(1) - (3)].str)) + strlen(inst) + 20];
						strcpy(ll,(yyvsp[(1) - (3)].str));
						strcpy(ll + strlen((yyvsp[(1) - (3)].str)),".");
						strcpy(ll + (strlen((yyvsp[(1) - (3)].str)) + 1), inst);
						PSI = (PlSymbol *) PlaceTable -> lookup(ll); 
						if(!PSI)
						{
							yyerror("place instance does not exist");
						}
						(* PSI -> place) += tl -> mult;
					}
				}
			}
    break;

  case 139:
#line 1415 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 140:
#line 1416 "readnet-syntax.yy"
    {(yyvsp[(3) - (3)].tlist) -> next = (yyvsp[(1) - (3)].tlist); (yyval.tlist) = (yyvsp[(3) - (3)].tlist);}
    break;

  case 141:
#line 1418 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 142:
#line 1419 "readnet-syntax.yy"
    { unsigned int i; sscanf((yyvsp[(3) - (3)].str),"%u",&i);(yyvsp[(1) - (3)].tlist) -> mult = i;
								 (yyval.tlist) = (yyvsp[(1) - (3)].tlist);}
    break;

  case 143:
#line 1422 "readnet-syntax.yy"
    {
		UTermList * tl;
		UVarTerm * vt;
		if(!LocalTable)
		{
			yyerror("only constant terms are allowed in this context");
		}
		VS =(VaSymbol *)  (LocalTable -> lookup((yyvsp[(1) - (1)].str)));
		if(!VS)
		{
			yyerror("undeclared variable in term");
		}
		tl = new UTermList;
		tl -> next = (UTermList *) 0;
		tl -> mult = 1;
		vt = new UVarTerm;
		tl -> t = vt;
		vt -> v = VS -> var;
		vt -> type = VS -> var -> type;
		(yyval.tlist) =tl;
		}
    break;

  case 144:
#line 1443 "readnet-syntax.yy"
    {
		FcSymbol * FS;
		UTermList * tl;
		UOpTerm * ot;
		FS = (FcSymbol *) GlobalTable -> lookup((yyvsp[(1) - (4)].str));
		if(!FS) yyerror("operation symbol not declared");
		if(FS ->kind != fc) yyerror("wrong symbol used as operation symbol");
		unsigned int i;
		UTermList * l;
		for(i=0,l=(yyvsp[(3) - (4)].tlist);l;i++,l=l->next);
		if(i != FS -> function -> arity) yyerror("wrong number of arguments");
		tl = new UTermList;
		tl -> next = (UTermList *) 0;
		tl -> mult = 1;
		ot = new UOpTerm;
		tl -> t = ot;
		ot -> arity = i;
		ot -> f = FS -> function;
		ot -> sub = new UTerm * [i+5];
		for(i=0,l=(yyvsp[(3) - (4)].tlist);i<ot -> arity;i++,l= l -> next)
		{
			if(!(ot -> f -> formalpar[i] -> type -> iscompatible(l -> t -> type)))
			{
				yyerror("type mismatch in subterm(s)");
			}
			ot -> sub[i] = l -> t;
		}
		ot -> type = ot -> f -> type;
		(yyval.tlist) = tl;
	   }
    break;

  case 145:
#line 1474 "readnet-syntax.yy"
    {(yyval.tlist) = (UTermList *) 0;}
    break;

  case 146:
#line 1475 "readnet-syntax.yy"
    { (yyval.tlist) = (yyvsp[(1) - (1)].tlist);}
    break;

  case 147:
#line 1476 "readnet-syntax.yy"
    {
			(yyvsp[(1) - (3)].tlist) -> next = (yyvsp[(3) - (3)].tlist);
			(yyval.tlist) = (yyvsp[(1) - (3)].tlist);
			}
    break;

  case 150:
#line 1485 "readnet-syntax.yy"
    {
  unsigned int card;
  unsigned int i;
  arc_list * current;
  /* 1. Transition anlegen */
  if(TransitionTable -> lookup((yyvsp[(2) - (10)].str)))
    {
      yyerror("transition name used twice");
    }
  TS = new TrSymbol((yyvsp[(2) - (10)].str));
  TS -> vars = LocalTable;
  TS -> guard = (yyvsp[(4) - (10)].ex);

  // unfold HL transitions
  // -> create transition instance for every assignment to the variables that
  //    matches the guard


  // init: initially, all variables have initial value

  while(1)
  {
	if(TS -> guard)
	{
		UValue * v;
		v = TS -> guard -> evaluate();
		if(((UBooValue * )v) -> v == false) goto nextass;
	}
	// A) create LL transition with current variable assignment

  /* generate name */
  char * llt;
  if((!LocalTable) || LocalTable -> card == 0)
  {
	llt = TS -> name;
	TS -> vars = (SymbolTab *) 0;
  }
  else
  {
  char ** assignment;
  unsigned int len;
  len = 0;
  assignment = new char * [LocalTable -> card + 1000];
  VaSymbol * vs;
  unsigned int i,j;
  j=0;
  for(i=0;i < LocalTable -> size; i++)
  {
	for(vs = (VaSymbol *) (LocalTable-> table[i]); vs ; vs = (VaSymbol *) vs -> next)
	{
		char * inst;
		inst = vs -> var -> value -> text();
		assignment[j] = new char[strlen(vs -> name) + 10 + strlen(inst)];
		strcpy(assignment[j],vs -> name);
		strcpy(assignment[j]+strlen(vs -> name),"=");
		strcpy(assignment[j]+strlen(vs -> name)+1,inst);
		len += strlen(assignment[j++]);
	}
  }
  llt = new char [ strlen(TS -> name)  + len + LocalTable -> card + 1000];
  strcpy(llt,TS->name);
  strcpy(llt + strlen(llt),".[");
  for(i=0;i<LocalTable -> card; i++)
  {
	strcpy(llt + strlen(llt),assignment[i]);
	strcpy(llt + strlen(llt),"|");
  }
  strcpy(llt + (strlen(llt) - 1), "]");
  }
  TrSymbol * TSI;
  if((!LocalTable) || LocalTable -> card == 0)
  {
	TSI = TS;
  }
  else
  {
  TSI = (TrSymbol *) TransitionTable -> lookup(llt);
  if(TSI) yyerror("transition instance already exists");
  TSI = new TrSymbol(llt);
  TSI -> vars = (SymbolTab *) 0;
  TSI -> guard = (UExpression *) 0;
  }
  T = TSI -> transition = new Transition(TSI -> name);
  T -> fairness = (yyvsp[(3) - (10)].value);
  /* 2. Inliste eintragen */
  /* HL-Boegen in LL-Boegen uebersetzen und zur Liste hinzufuegen */
  arc_list * root;
  root = (yyvsp[(6) - (10)].al);
  for(current = root;current; current = current -> next)
  {
	if(current -> mt)
	{
		// traverse multiterm
		arc_list * a;
		UTermList * mc;
		UValueList * vl;
		UValueList * vc;
		UValue * pv;
		pv = current -> place -> sort -> make();
		for(mc = current -> mt; mc ; mc = mc -> next)
		{	
			vl = mc -> t -> evaluate();

			for(vc = vl; vc; vc  = vc -> next)
			{
				char * inst;
				char * ll;
				pv -> assign(vc -> val);
				inst = pv -> text();
				ll = new char [strlen(current -> place -> name) + strlen(inst) + 20];
				strcpy(ll,current->place->name);
				strcpy(ll+strlen(current->place->name),".");
				strcpy(ll+strlen(current->place->name)+1,inst);
				PS = (PlSymbol *) PlaceTable -> lookup(ll);
				if(!ll) yyerror("place instance does not exist");
				if(PS -> sort) yyerror("arcs to HL places are not allowed");
				a = new arc_list;
				a -> place = PS;
				a -> mt = (UTermList *) 0;
				a -> nu =mc -> mult;
				a -> next = root;
				root = a;
			}
		}
	}
  }
  /* Anzahl der Boegen */
  for(card = 0, current = root;current;card++,current = current -> next);
  T->ArrivingArcs = new  Arc * [card+10];
  /* Schleife ueber alle Boegen */
  for(current = root;current;current = current -> next)
    {
	  /* Bogen ist nur HL-Bogen */
	  if(current -> place -> sort) continue;
      /* gibt es Bogen schon? */

      for(i = 0; i < T->NrOfArriving;i++)
	{
	  if(current->place -> place == T->ArrivingArcs[i]->pl)
	    {
	      /* Bogen existiert, nur Vielfachheit addieren */
	      *(T->ArrivingArcs[i]) += current->nu;
	      break;
	    }
	}
      if(i>=T->NrOfArriving)
	{
	  T->ArrivingArcs[T->NrOfArriving] = new Arc(T,current->place->place,true,current->nu);
	  T->NrOfArriving++;
	  current -> place -> place -> references ++;
	}
    }
  /* 2. Outliste eintragen */
  root = (yyvsp[(9) - (10)].al);
  for(current = root;current; current = current -> next)
  {
	if(current -> mt)
	{
		// traverse multiterm
		arc_list * a;
		UTermList * mc;
		UValueList * vl;
		UValueList * vc;
		UValue * pv;
		pv = current -> place -> sort -> make();
		for(mc = current -> mt; mc ; mc = mc -> next)
		{	
			vl = mc -> t -> evaluate();
			for(vc = vl; vc; vc  = vc -> next)
			{
				char * inst;
				char * ll;
				pv -> assign(vc -> val);
				inst = pv -> text();
				ll = new char [strlen(current -> place -> name) + strlen(inst) + 20];
				strcpy(ll,current->place->name);
				strcpy(ll+strlen(current->place->name),".");
				strcpy(ll+strlen(current->place->name)+1,inst);
				PS = (PlSymbol *) PlaceTable -> lookup(ll);
				if(!ll) yyerror("place instance does not exist");
				a = new arc_list;
				a -> place = PS;
				a -> mt = (UTermList *) 0;
				a -> nu =mc -> mult;
				a -> next = root;
				root = a;
			}
		}
	}
  }
  /* Anzahl der Boegen */
  for(card = 0, current = root;current;card++,current = current -> next);
  T->LeavingArcs = new  Arc * [card+10];
  /* Schleife ueber alle Boegen */
  for(current = root;current;current = current -> next)
    {
	  /* Bogen ist nur HL-Bogen */
	  if(current -> place -> sort) continue;
      /* gibt es Bogen schon? */

      for(i = 0; i < T->NrOfLeaving;i++)
	{
	  if(current->place -> place == T->LeavingArcs[i]->pl)
	    {
	      /* Bogen existiert, nur Vielfachheit addieren */
	      *(T->LeavingArcs[i]) += current->nu;
	      break;
	    }
	}
      if(i>=T->NrOfLeaving)
	{
	  T->LeavingArcs[T->NrOfLeaving] = new Arc(T,current->place -> place,false,current->nu);
	  T -> NrOfLeaving++;
	  current -> place -> place -> references ++;
	}
    }
	// B) switch to next assignment
nextass:
	if((!LocalTable) || LocalTable -> card == 0) break;
	unsigned int k;
	VaSymbol * vv;
	for(k=0;k < LocalTable -> size;k++)
	{
		for(vv = (VaSymbol *) (LocalTable-> table[k]); vv;vv = (VaSymbol *) (vv -> next))
		{
			(*(vv -> var -> value)) ++;
			if(!(vv -> var -> value -> isfirst()) ) break;
		}
		if(vv) break;
	}
	if(!vv) break;
	}
}
    break;

  case 151:
#line 1719 "readnet-syntax.yy"
    {(yyval.value) = 0;}
    break;

  case 152:
#line 1720 "readnet-syntax.yy"
    {(yyval.value) = 1;}
    break;

  case 153:
#line 1721 "readnet-syntax.yy"
    {(yyval.value) = 2;}
    break;

  case 154:
#line 1723 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(256);}
    break;

  case 155:
#line 1724 "readnet-syntax.yy"
    {LocalTable = new SymbolTab(256);}
    break;

  case 156:
#line 1726 "readnet-syntax.yy"
    { (yyval.ex) = (UExpression *) 0; }
    break;

  case 157:
#line 1727 "readnet-syntax.yy"
    {if((yyvsp[(2) - (2)].ex) -> type -> tag != boo) yyerror("guard expression must be boolean"); (yyval.ex) = (yyvsp[(2) - (2)].ex);}
    break;

  case 158:
#line 1729 "readnet-syntax.yy"
    { (yyval.al) = (arc_list *) 0;}
    break;

  case 159:
#line 1730 "readnet-syntax.yy"
    {(yyval.al) = (yyvsp[(1) - (1)].al);}
    break;

  case 160:
#line 1731 "readnet-syntax.yy"
    {
      (yyvsp[(1) - (3)].al)-> next = (yyvsp[(3) - (3)].al);
	  (yyval.al) = (yyvsp[(1) - (3)].al);
    }
    break;

  case 161:
#line 1736 "readnet-syntax.yy"
    {
      unsigned int i;
      PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
      if(!PS)
	{
	  yyerror("place does not exist");
	}
	if(PS -> sort)
	{
		yyerror("arc expression of high level places must be term expressions");
	}
      (yyval.al) = new arc_list;
      (yyval.al) -> place = PS;
      (yyval.al)-> next = (arc_list *)  0;
      sscanf((yyvsp[(3) - (3)].str),"%u",&i);
      (yyval.al) -> nu = i;
	  (yyval.al) -> mt = (UTermList *) 0;
    }
    break;

  case 162:
#line 1754 "readnet-syntax.yy"
    {
		UTermList * tl;
		PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (3)].str));
		if(!PS)
		{
			yyerror("place does not exist");
		}
		if(!(PS -> sort))
		{
			yyerror("low level places require numerical multiplicity");
		}
		(yyval.al) = new arc_list;
		(yyval.al) -> place = PS; 
		(yyval.al) -> nu = 0;
		(yyval.al) -> mt = (yyvsp[(3) - (3)].tlist);
		(yyval.al) -> next = (arc_list *) 0;
		for(tl = (yyvsp[(3) - (3)].tlist); tl; tl = tl -> next)
		{
			if(!(PS -> sort -> iscompatible(tl -> t -> type)))
			{
				yyerror("type mismatch between place and arc expression");
			}
		}
	}
    break;

  case 163:
#line 1779 "readnet-syntax.yy"
    { 
			(yyval.ex) = new UIntconstantExpression();
			sscanf((yyvsp[(1) - (1)].str),"%u",&(((UIntconstantExpression *) (yyval.ex)) -> nu));
			}
    break;

  case 164:
#line 1784 "readnet-syntax.yy"
    {
			if((yyvsp[(2) - (3)].ex) -> type -> tag != num)
			{
				yyerror("integer expression expected");
			}
			(yyval.ex) = (yyvsp[(2) - (3)].ex);
			}
    break;

  case 165:
#line 1792 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = eq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif
				    }
    break;

  case 166:
#line 1799 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = neq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif
				  }
    break;

  case 167:
#line 1806 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA		   
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = leq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif
				  }
    break;

  case 168:
#line 1813 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type= geq;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif
				    }
    break;

  case 169:
#line 1820 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = lt;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif
				    }
    break;

  case 170:
#line 1827 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA    
					((hlatomicformula *) (yyvsp[(1) - (3)].form)) -> k = (yyvsp[(3) - (3)].ex);
					(yyvsp[(1) - (3)].form) -> type = gt;
					(yyval.form) = (yyvsp[(1) - (3)].form);
#endif 	
	                            }
    break;

  case 171:
#line 1834 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					   (yyval.form) = new binarybooleanformula(conj,(yyvsp[(1) - (3)].form),(yyvsp[(3) - (3)].form));
#endif
                                           }
    break;

  case 172:
#line 1839 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
			                   (yyval.form) = new binarybooleanformula(disj,(yyvsp[(1) - (3)].form),(yyvsp[(3) - (3)].form));
#endif
                                          }
    break;

  case 173:
#line 1844 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                        (yyval.form) = new unarybooleanformula(neg,(yyvsp[(2) - (2)].form));
#endif
                                 }
    break;

  case 174:
#line 1849 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
				if((yyvsp[(2) - (3)].ex) -> type -> tag != boo)
				{	
					yyerror("formula requires boolean expression");
				}
				(yyval.form) = new staticformula((yyvsp[(2) - (3)].ex));
#endif
					   }
    break;

  case 175:
#line 1858 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
		(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
		(yyval.form) = new quantifiedformula(qe,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
#endif
		}
    break;

  case 176:
#line 1864 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
		(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
		(yyval.form) = new quantifiedformula(qa,(yyvsp[(2) - (4)].varsy)->var,(yyvsp[(4) - (4)].form));
#endif
		}
    break;

  case 177:
#line 1870 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                     (yyval.form) = (yyvsp[(2) - (3)].form);
#endif
                                    }
    break;

  case 178:
#line 1875 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                  (yyval.form) = new untilformula(eu,(yyvsp[(4) - (7)].form),(yyvsp[(6) - (7)].form),(transitionformula *) (yyvsp[(2) - (7)].form));
#endif
                                                              }
    break;

  case 179:
#line 1880 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                             (yyval.form) = new untilformula(au,(yyvsp[(4) - (7)].form),(yyvsp[(6) - (7)].form),(transitionformula *) (yyvsp[(2) - (7)].form));
#endif
                                                              }
    break;

  case 180:
#line 1885 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                           (yyval.form) = new unarytemporalformula(eg,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                           }
    break;

  case 181:
#line 1890 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                (yyval.form) = new unarytemporalformula(ag,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                           }
    break;

  case 182:
#line 1895 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                      (yyval.form) = new unarytemporalformula(ex,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                         }
    break;

  case 183:
#line 1900 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
				(yyval.form) = new unarytemporalformula(ax,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                        }
    break;

  case 184:
#line 1905 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
                                      (yyval.form) = new unarytemporalformula(ef,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                         }
    break;

  case 185:
#line 1910 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
				(yyval.form) = new unarytemporalformula(af,(yyvsp[(4) - (4)].form),(transitionformula *) (yyvsp[(2) - (4)].form));
#endif
                                        }
    break;

  case 186:
#line 1916 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
				    PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (1)].str));
                    if(!PS) yyerror("Place does not exist");
					if(PS -> sort) yyerror("HL places require instance");
					(yyval.form) = new hlatomicformula(neq,PS,(UExpression *) 0);
#endif
				  }
    break;

  case 187:
#line 1924 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
				    PS = (PlSymbol *) PlaceTable -> lookup((yyvsp[(1) - (5)].str));
                    if(!PS) yyerror("Place does not exist");
                    if(!(PS-> sort)) yyerror("LL places do not require instance");
					if(!(PS -> sort ->iscompatible((yyvsp[(4) - (5)].ex) -> type)))
					{
						yyerror("place color incompatible to place sort");
					}
					(yyval.form) = new hlatomicformula(neq,PS,(yyvsp[(4) - (5)].ex));
#endif
				}
    break;

  case 188:
#line 1937 "readnet-syntax.yy"
    {
		UVar * vv;
		VS = (VaSymbol *) LocalTable -> lookup((yyvsp[(1) - (3)].str));
		if(VS) yyerror("variable used twice in formula");
		vv = new UVar((yyvsp[(3) - (3)].t));
		(yyval.varsy) = new VaSymbol((yyvsp[(1) - (3)].str),vv);
	}
    break;

  case 189:
#line 1945 "readnet-syntax.yy"
    { (yyval.form) = (transitionformula *) 0;}
    break;

  case 190:
#line 1946 "readnet-syntax.yy"
    { (yyval.form) = (yyvsp[(1) - (1)].form);}
    break;

  case 191:
#line 1948 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
					(yyval.form) = new quantifiedformula(qe,(yyvsp[(2) - (4)].varsy) -> var,(yyvsp[(4) - (4)].form));
#endif
					}
    break;

  case 192:
#line 1954 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					(yyvsp[(2) - (4)].varsy) -> name[0] = '\0';
					(yyval.form) = new quantifiedformula(qa,(yyvsp[(2) - (4)].varsy) -> var,(yyvsp[(4) - (4)].form));
#endif
					}
    break;

  case 193:
#line 1960 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
						(yyval.form) = new binarybooleanformula(conj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
#endif
					}
    break;

  case 194:
#line 1965 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
						(yyval.form) = new binarybooleanformula(disj, (yyvsp[(1) - (3)].form), (yyvsp[(3) - (3)].form));
#endif
					}
    break;

  case 195:
#line 1970 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
						(yyval.form) = new unarybooleanformula(neg,(yyvsp[(2) - (2)].form));
#endif
					}
    break;

  case 196:
#line 1975 "readnet-syntax.yy"
    {(yyval.form) = (yyvsp[(2) - (3)].form);}
    break;

  case 197:
#line 1976 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					if((yyvsp[(1) - (1)].ts)->vars && (yyvsp[(1) - (1)].ts) -> vars -> card)
					{
						yyerror("HL transition requires firing mode");
					}
					(yyval.form) = new transitionformula((yyvsp[(1) - (1)].ts) -> transition);
#endif
				}
    break;

  case 198:
#line 1985 "readnet-syntax.yy"
    {
#ifdef WITHFORMULA
					if((! (yyvsp[(1) - (5)].ts) -> vars) || ((yyvsp[(1) - (5)].ts) -> vars -> card == 0))
					{
						yyerror("LL transition does not require firing mode");
					}
					(yyval.form) = new transitionformula((yyvsp[(1) - (5)].ts),(yyvsp[(4) - (5)].fm));
#endif
				}
    break;

  case 199:
#line 1995 "readnet-syntax.yy"
    {
					TS = (TrSymbol *) TransitionTable -> lookup((yyvsp[(1) - (1)].str));
					if(!TS) yyerror("transition does not exist");
					(yyval.ts) = TS;
				}
    break;

  case 200:
#line 2001 "readnet-syntax.yy"
    { (yyval.fm) = (yyvsp[(1) - (1)].fm);}
    break;

  case 201:
#line 2002 "readnet-syntax.yy"
    {
					(yyvsp[(1) - (3)].fm) -> next = (yyvsp[(3) - (3)].fm);
					(yyval.fm) = (yyvsp[(1) - (3)].fm);
				}
    break;

  case 202:
#line 2007 "readnet-syntax.yy"
    {
			VS = (VaSymbol *) (TS -> vars -> lookup((yyvsp[(1) - (3)].str)));
			if(!VS) yyerror("no such transition variable");
			if(! (VS -> var -> type -> iscompatible((yyvsp[(3) - (3)].ex) -> type)))
			{
				yyerror("variable binding incompatible with variable type");
			}
			(yyval.fm) = new fmode;
			(yyval.fm) -> v = VS;
			(yyval.fm) -> t = (yyvsp[(3) - (3)].ex) ;
			(yyval.fm) -> next = (fmode *) 0;
		}
    break;


/* Line 1267 of yacc.c.  */
#line 4297 "readnet-syntax.cc"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 2021 "readnet-syntax.yy"



char * diagnosefilename;


void readnet()
{
	yydebug = 0;
	diagnosefilename = (char *) 0;
	if(netfile)
	{
		yyin = fopen(netfile,"r");
		if(!yyin)
		{
			cerr << "cannot open netfile: " << netfile << "\n";
			exit(4);
		}
		diagnosefilename = netfile;
	}
	GlobalTable = new SymbolTab(1024);
	TheBooType = new UBooType();
	TheNumType = new UNumType(0,INT_MAX);
	yyparse();
	unsigned int ii;
	for(ii=0;ii < Places[0]->cnt;ii++)
	{
	 	CurrentMarking[ii] = Places[ii]->initial_marking;
		Places[ii]->index = ii;
	}

#ifdef WITHFORMULA
	  F = F -> replacequantifiers();
	  F -> tempcard = 0;
	  F = F -> merge();
#if defined(MODELCHECKING) 
	unsigned int i;
	for(i=0;i< Transitions[0]->cnt;i++)
	{
		Transitions[i] -> lstfired = new unsigned int [F -> tempcard];
		Transitions[i] -> lstdisabled = new unsigned int [F -> tempcard];
	}
#endif
#endif
}

void yyerror(char * mess)
{
        printf("syntaxerror at line %d of file %s:  %s\n",yylineno, diagnosefilename,mess);
		exit(3);
}


