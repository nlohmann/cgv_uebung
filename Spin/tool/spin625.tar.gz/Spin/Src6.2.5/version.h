#define SpinVersion	"Spin Version 6.2.5 -- 3 May 2013"
